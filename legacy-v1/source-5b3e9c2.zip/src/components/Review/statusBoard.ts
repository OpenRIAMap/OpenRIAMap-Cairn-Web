import type { ReviewAuthorizationContext, ReviewReleaseGateSnapshot, ReviewSubmissionState } from './contracts';

const activeReleaseGateStates = new Set<ReviewReleaseGateSnapshot['state']>([
  'prechecking',
  'awaiting-confirmation',
  'queueing',
  'running',
  'mirroring',
]);

/**
 * Treat an expired lease as inactive for presentation and retry decisions.
 * A missing or malformed lease remains conservatively active: only an
 * explicit, valid expiry can make an active-looking gate eligible for retry.
 * The authority must still acquire the lock conditionally before any release.
 */
export function isReviewReleaseGateLeaseActive(
  gate: Pick<ReviewReleaseGateSnapshot, 'state' | 'leaseExpiresAt'>,
  now = Date.now(),
): boolean {
  if (!activeReleaseGateStates.has(gate.state)) return false;
  const expiresAt = Date.parse(gate.leaseExpiresAt ?? '');
  return !Number.isFinite(expiresAt) || expiresAt > now;
}

export function isReviewReleaseGateLeaseExpired(
  gate: Pick<ReviewReleaseGateSnapshot, 'state' | 'leaseExpiresAt'>,
  now = Date.now(),
): boolean {
  if (!activeReleaseGateStates.has(gate.state)) return false;
  const expiresAt = Date.parse(gate.leaseExpiresAt ?? '');
  return Number.isFinite(expiresAt) && expiresAt <= now;
}

/**
 * Package state is separate from the immutable review revision it references.
 * Viewing another revision never transfers a saved decision to that revision.
 */
export type ReviewStatusBoardState = Extract<ReviewSubmissionState, 'pending' | 'approved' | 'rejected' | 'archived'>;
export type ReviewStatusDecisionAction = 'approve' | 'reject' | 'request-changes' | 'archive' | 'reopen';

/** Immutable Control evidence for a saved approve/reject lamp. */
export type ReviewStatusDecisionRecord = {
  decisionId: string;
  recordSha256: string;
  controlCommit: string;
  decision: Extract<ReviewStatusDecisionAction, 'approve' | 'reject'>;
  stateVersion: number;
};

export type ReviewStatusBoardEntry = {
  submissionId: string;
  state: ReviewStatusBoardState;
  decisionRevisionId: string | null;
  /** Keeps reject and request-changes distinct while sharing the rejected lamp. */
  decisionAction?: ReviewStatusDecisionAction;
  /** Server-authored immutable evidence; clients never submit this field. */
  decisionRecord?: ReviewStatusDecisionRecord;
  updatedAt: string;
  updatedBy: ReviewAuthorizationContext;
  reason?: string;
};

export type ReviewStatusBoardSnapshot = {
  schemaVersion: 'cairn.review-status-board.v1';
  boardVersion: number;
  entries: readonly ReviewStatusBoardEntry[];
  updatedAt: string;
};

export type ReviewStatusBoardDraft = {
  baseBoardVersion: number;
  entries: readonly ReviewStatusBoardEntry[];
};

export type ReviewStatusBoardDifference = {
  submissionId: string;
  local: ReviewStatusBoardEntry | null;
  remote: ReviewStatusBoardEntry | null;
  kind: 'missing-local' | 'missing-remote' | 'state-changed' | 'revision-changed' | 'reason-changed' | 'unchanged';
};

export type ReviewStatusBoardSaveRequest = {
  requestId: string;
  correlationId: string;
  idempotencyKey: string;
  expectedBoardVersion: number;
  entries: readonly ReviewStatusBoardEntry[];
  actor: ReviewAuthorizationContext;
  occurredAt: string;
};

export type ReviewStatusBoardSaveResult = {
  board: ReviewStatusBoardSnapshot;
  differences: readonly ReviewStatusBoardDifference[];
  accepted: boolean;
};

export type ReviewReleasePlanItem = {
  submissionId: string;
  state: Extract<ReviewStatusBoardState, 'approved' | 'rejected'>;
  decisionRevisionId: string;
  statusUpdatedAt: string;
};

export type ReviewReleasePlan = {
  schemaVersion: 'cairn.review-release-plan.v1';
  sourceBoardVersion: number;
  selected: readonly ReviewReleasePlanItem[];
};

function bySubmissionId(entries: readonly ReviewStatusBoardEntry[]) {
  return new Map(entries.map((entry) => [entry.submissionId, entry]));
}

export function createReviewStatusBoardDraft(board: ReviewStatusBoardSnapshot): ReviewStatusBoardDraft {
  return { baseBoardVersion: board.boardVersion, entries: board.entries.map((entry) => ({ ...entry, updatedBy: { ...entry.updatedBy } })) };
}

export function compareReviewStatusBoards(local: readonly ReviewStatusBoardEntry[], remote: readonly ReviewStatusBoardEntry[]): ReviewStatusBoardDifference[] {
  const localById = bySubmissionId(local);
  const remoteById = bySubmissionId(remote);
  return [...new Set([...localById.keys(), ...remoteById.keys()])].sort().map((submissionId) => {
    const left = localById.get(submissionId) ?? null;
    const right = remoteById.get(submissionId) ?? null;
    if (!left) return { submissionId, local: null, remote: right, kind: 'missing-local' };
    if (!right) return { submissionId, local: left, remote: null, kind: 'missing-remote' };
    if (left.state !== right.state) return { submissionId, local: left, remote: right, kind: 'state-changed' };
    if (left.decisionRevisionId !== right.decisionRevisionId) return { submissionId, local: left, remote: right, kind: 'revision-changed' };
    if ((left.decisionAction ?? '') !== (right.decisionAction ?? '')) return { submissionId, local: left, remote: right, kind: 'state-changed' };
    if ((left.reason ?? '') !== (right.reason ?? '')) return { submissionId, local: left, remote: right, kind: 'reason-changed' };
    return { submissionId, local: left, remote: right, kind: 'unchanged' };
  });
}

export function createReviewReleasePlan(board: ReviewStatusBoardSnapshot, submissionIds: readonly string[]): ReviewReleasePlan {
  const selectedIds = new Set(submissionIds);
  const selected = board.entries
    .filter((entry): entry is ReviewStatusBoardEntry & { decisionRevisionId: string } => selectedIds.has(entry.submissionId)
      && (entry.state === 'approved' || entry.state === 'rejected') && Boolean(entry.decisionRevisionId))
    .map((entry): ReviewReleasePlanItem => ({ submissionId: entry.submissionId, state: entry.state as 'approved' | 'rejected', decisionRevisionId: entry.decisionRevisionId, statusUpdatedAt: entry.updatedAt }))
    .sort((left, right) => left.statusUpdatedAt.localeCompare(right.statusUpdatedAt) || left.submissionId.localeCompare(right.submissionId));
  return { schemaVersion: 'cairn.review-release-plan.v1', sourceBoardVersion: board.boardVersion, selected };
}

export function isReviewStatusBoardDirty(draft: ReviewStatusBoardDraft, board: ReviewStatusBoardSnapshot): boolean {
  return compareReviewStatusBoards(draft.entries, board.entries).some((difference) => difference.kind !== 'unchanged');
}

import { getApplicationGeneration, getApplicationSettings, applicationWorld, enabledApplicationWorldId, moduleEnabled, subscribeApplication, registerApplicationGuard } from '@/core/project/applicationRuntime';
import { useSyncExternalStore } from 'react';
import { isNativeConfigRevision } from '../../configStudio/contract';
import { MAP_ZOOM_BOUNDS, TILE_ZOOM_BOUNDS } from '@/lib/mapZoom';
import { Suspense, lazy, useEffect, useRef, useState, useCallback, useMemo } from 'react';
import MobileBottomSheet from '@/components/Mobile/MobileBottomSheet';
import MobileQuickDock from '@/components/Mobile/MobileQuickDock';
import MobileFeatureJsonPanel from '@/components/Mobile/MobileFeatureJsonPanel';
import MobileFeatureSharePanel from '@/components/Mobile/MobileFeatureSharePanel';
import MobileFloorPanel from '@/components/Mobile/MobileFloorPanel';
import * as L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { createDynmapCRS, getWorldConfig, DynmapProjection } from '@/lib/DynmapProjection';
import { DynmapTileLayer, createDynmapTileLayer } from '@/lib/DynmapTileLayer';
import { createSketchTileLayer } from '@/lib/SketchTileLayer';
import { createWatercolorTileLayer } from '@/lib/SketchTileLayer';
import { PlayerLayer } from './PlayerLayer';
import { nextPlayerPollDelayMs } from '@/lib/playerPollingPolicy';
import { RouteHighlightLayer, type RouteHighlightData } from './RouteHighlightLayer';
import { LineHighlightLayer } from './LineHighlightLayer';
import { WorldSwitcher } from './WorldSwitcher';
import { SearchBar, type SearchResult } from '../Search/SearchBar';
import { getMatchingRuleButtonIds } from '../Rules/ButtonRule/buttonRuleFilter';
import { NavigationPanel, type NavigationInitialPoint } from '../Navigation/NavigationPanel';
import { AttributeQueryPanel } from '../AttributeQuery/AttributeQueryPanel';
import { PlayerDetailCard } from '../PlayerDetail/PlayerDetailCard';
import { Toolbar, LayerControl, AboutCard } from '../Toolbar/Toolbar';
import { PlayersList } from '../Players/PlayersList';
import { LoadingOverlay } from '../Loading/LoadingOverlay';
import { DraggablePanel } from '../DraggablePanel/DraggablePanel';
import { SettingsPanel } from '../Settings/SettingsPanel';
import { openriamapGithubReviewAuth } from '@/components/Review/openriamapReviewAuth';
import { useDataStore } from '@/store/dataStore';
import { ensureLegacyDataLoaded } from '@/lib/legacyDataLoader';
import { useRuleDataStore } from '@/store/ruleDataStore';
import { useLoadingStore } from '@/store/loadingStore';
import { fetchPlayersDetailed } from '@/lib/playerApi';
import { loadMapSettings, saveMapSettings, MapStyle } from '@/lib/cookies';
import type { ParsedStation, ParsedLine, Coordinate, Player } from '@/types';
import type { ParsedLandmark } from '@/components/Legacy/data/landmarkParser';
import type { MeasuringModuleHandle, ReviewWorkspaceSaveArtifact } from '@/components/Mapping/core/MeasuringModule';
import type { MeasurementToolsHandle } from '@/components/Mapping/core/Mtools';
import { useFeatureModuleStore } from '@/store/featureModuleStore';
import { WorkspaceTransitionCoordinator, type WorkspaceKind, type WorkspaceTransition } from './workspaceTransitionCoordinator';

import RuleDrivenLayer from '@/components/Rules/core/RuleDrivenLayer';
import { hasEnabledTemporaryRuleSources } from '@/components/Rules/data/temporaryRuleSession';
import { resolveFeatureCardComponent } from '@/components/Rules/cardrules/featureCardRegistry';
import { pickIdFieldValue, type FeatureRecord } from '@/components/Rules/rendering/renderRules';
import RuleButtonPanel from '@/components/Rules/ButtonRule/RuleButtonPanel';
import { useRuleButtonState } from '@/components/Rules/ButtonRule/ruleButtonState';
import { normalizeRuleSourceWorldId } from '@/components/Rules/data/ruleDataSources';

import { formatGridNumber, snapWorldPointByMode } from '@/lib/gridSnapUtils';
import AppButton from '@/components/ui/AppButton';
import AppCard from '@/components/ui/AppCard';
import ToolIconButton from '@/components/Toolbar/ToolIconButton';
import { Globe2, PanelsTopLeft, Layers3, SlidersHorizontal, Plus, Minus, Pencil, RefreshCw, Ruler, User, History } from 'lucide-react';
import { buildBuildingNameIndex, getRuleCategoryLabelWithParent, getRuleDisplayName } from '@/components/Search/searchRuleTables';
import { getRuleSearchPool } from '@/components/Rules/search/ruleSearchRegistry';
import { consumeFeatureShareTargetFromLocation, normalizePlayerShareId, type FeatureSharePayload, type FeatureShareTarget, type PlayerShareTarget, type ShareParseResult } from '@/lib/featureShareLink';
import { PublicReleaseRecordsPanel, ReviewConfirmationHost, ReviewModuleLauncher, createReviewPackageSession, type CairnMapModuleMode, type ReviewInboxItem, type ReviewPackageSession } from '@/components/Review';
import { openriamapReviewPackageUploader, uploadRiaReviewRevision } from '@/components/Review/riaReviewPackageUploader';
import type { ConfigPackageV3 } from '@/configStudio/types';

// ===== 导航“图上选取”：MapContainer 统一派发地图点击事件 =====
type MapClickWorldPointEventDetail = {
  worldId: string;
  point: { x: number; y: number; z: number };
};


type MobilePanelKey = null | 'navigation' | 'attributeQuery' | 'players' | 'about' | 'settings' | 'releaseRecords' | 'featureJson' | 'featureShare';
type MobileQuickPanelKey = null | 'worlds' | 'toolbar' | 'ruleButtons' | 'modeTools';

type PendingShareTarget =
  | { type: 'feature'; target: FeatureShareTarget }
  | { type: 'player'; target: PlayerShareTarget };

/** Share links, cookies and V1 data have historically used `Z`, `0`, Chinese
 * names and canonical IDs interchangeably.  Normalize at the map boundary so
 * tiles, data loading, search and Config V3 all observe one World value. */
function normalizeShareWorld<T extends { worldId: string }>(target: T): T {
  return { ...target, worldId: normalizeRuleSourceWorldId(target.worldId) };
}

type ShareLookupState = {
  pending: PendingShareTarget;
  phase: 'waiting-map-ready' | 'waiting-pool' | 'searching-feature' | 'waiting-player-list' | 'searching-player';
  attempt: number;
  maxAttempts: number;
};

const SHARE_LOOKUP_RETRY_MS = 250;
const SHARE_LOOKUP_WAIT_POOL_ATTEMPTS = 12;
const SHARE_LOOKUP_SEARCH_ATTEMPTS = 8;
const PLAYER_SHARE_LOOKUP_ATTEMPTS = 16;

function createShareLookupState(
  pending: PendingShareTarget,
  phase: ShareLookupState['phase'] = pending.type === 'player' ? 'waiting-player-list' : 'waiting-pool',
  attempt = 0,
  maxAttempts = pending.type === 'player' ? PLAYER_SHARE_LOOKUP_ATTEMPTS : SHARE_LOOKUP_WAIT_POOL_ATTEMPTS,
): ShareLookupState {
  return { pending, phase, attempt, maxAttempts };
}

function getShareLookupText(state: ShareLookupState): string {
  switch (state.phase) {
    case 'waiting-map-ready':
      return '正在等待地图数据加载完成...';
    case 'waiting-pool':
      return '正在准备分享目标索引...';
    case 'searching-feature':
      return '正在查找分享目标...';
    case 'waiting-player-list':
      return '正在同步玩家状态...';
    case 'searching-player':
      return '正在查找在线玩家...';
    default:
      return '正在打开分享链接...';
  }
}

function getShareLookupProgress(state: ShareLookupState): number {
  if (state.maxAttempts <= 0) return 8;
  return Math.min(100, Math.max(8, Math.round((state.attempt / state.maxAttempts) * 100)));
}

// 世界配置
const LazyMappingWorkspace = lazy(() => import('@/components/Mapping/MappingWorkspace'));
const LazyReviewWorkspace = lazy(() => import('@/components/Review/ReviewWorkspace'));
const LazyReviewModule = lazy(() => import('@/components/Review/ReviewModule'));
const LazyMeasurementToolsModule = lazy(() => import('@/components/Mapping/core/Mtools'));
const LazyRailwayLayer = lazy(() => import('@/components/Legacy/map/RailwayLayer').then((mod) => ({ default: mod.RailwayLayer })));
const LazyLandmarkLayer = lazy(() => import('@/components/Legacy/map/LandmarkLayer').then((mod) => ({ default: mod.LandmarkLayer })));
const LazyLineDetailCard = lazy(() => import('@/components/Legacy/detail/LineDetailCard').then((mod) => ({ default: mod.LineDetailCard })));
const LazyPointDetailCard = lazy(() => import('@/components/Legacy/detail/PointDetailCard').then((mod) => ({ default: mod.PointDetailCard })));
const LazyLinesPage = lazy(() => import('@/components/Legacy/lines/LinesPage').then((mod) => ({ default: mod.LinesPage })));


function getRuleCenterCoord(r: FeatureRecord): Coordinate | null {
  if (r?.p3) return { x: r.p3.x, y: r.p3.y ?? 64, z: r.p3.z };
  const coords = Array.isArray(r?.coords3) ? r.coords3 : [];
  if (!coords.length) return null;
  let minX = Number.POSITIVE_INFINITY;
  let minY = Number.POSITIVE_INFINITY;
  let minZ = Number.POSITIVE_INFINITY;
  let maxX = Number.NEGATIVE_INFINITY;
  let maxY = Number.NEGATIVE_INFINITY;
  let maxZ = Number.NEGATIVE_INFINITY;
  for (const c of coords) {
    minX = Math.min(minX, c.x);
    minY = Math.min(minY, c.y ?? 64);
    minZ = Math.min(minZ, c.z);
    maxX = Math.max(maxX, c.x);
    maxY = Math.max(maxY, c.y ?? 64);
    maxZ = Math.max(maxZ, c.z);
  }
  if (!Number.isFinite(minX) || !Number.isFinite(minZ) || !Number.isFinite(maxX) || !Number.isFinite(maxZ)) return null;
  return { x: (minX + maxX) / 2, y: Number.isFinite(minY + maxY) ? (minY + maxY) / 2 : 64, z: (minZ + maxZ) / 2 };
}

function getRuleRepresentativeCoord(r: FeatureRecord): Coordinate | null {
  if (r?.p3) return { x: r.p3.x, y: r.p3.y ?? 64, z: r.p3.z };
  const coords = Array.isArray(r?.coords3) ? r.coords3 : [];
  if (!coords.length) return null;

  const bboxCenter = () => getRuleCenterCoord(r);
  if (r.type === 'Polyline' && coords.length >= 2) {
    let total = 0;
    const segLens: number[] = [];
    for (let i = 1; i < coords.length; i++) {
      const dx = coords[i].x - coords[i - 1].x;
      const dz = coords[i].z - coords[i - 1].z;
      const len = Math.hypot(dx, dz);
      segLens.push(len);
      total += len;
    }
    if (total <= 0) return bboxCenter();
    const half = total / 2;
    let acc = 0;
    for (let i = 1; i < coords.length; i++) {
      const len = segLens[i - 1] ?? 0;
      if (acc + len >= half && len > 0) {
        const t = (half - acc) / len;
        return {
          x: coords[i - 1].x + (coords[i].x - coords[i - 1].x) * t,
          y: coords[i - 1].y ?? 64,
          z: coords[i - 1].z + (coords[i].z - coords[i - 1].z) * t,
        };
      }
      acc += len;
    }
  }
  return bboxCenter();
}

function getRuleShareId(r: FeatureRecord): string {
  const cls = String(r?.meta?.Class ?? r?.featureInfo?.Class ?? '').trim();
  const picked = pickIdFieldValue(r?.featureInfo, cls);
  return String(r?.meta?.idValue ?? picked.idValue ?? r?.featureInfo?.ID ?? '').trim();
}

function findRuleByShareTarget(pool: FeatureRecord[], target: FeatureShareTarget): FeatureRecord | null {
  const wanted = String(target.featureId ?? '').trim();
  if (!wanted) return null;
  return pool.find((r) => getRuleShareId(r) === wanted) ?? null;
}

function buildNavigationInitialPointFromFeature(feature: FeatureRecord, title: string): NavigationInitialPoint | null {
  const coord = getRuleRepresentativeCoord(feature);
  if (!coord) return null;
  const display = getRuleDisplayName(feature);
  const name = String(title || display.name || display.rawName || getRuleShareId(feature) || '当前要素').trim();
  return {
    id: getRuleShareId(feature),
    name,
    coord,
    extra: '当前要素',
    ruleRecord: feature,
    nonce: Date.now(),
  };
}

function buildNavigationInitialPointFromPlayer(player: Player): NavigationInitialPoint {
  const coord: Coordinate = { x: player.x, y: player.y ?? 64, z: player.z };
  return {
    id: player.account || player.name,
    name: `X:${formatGridNumber(coord.x)}  Z:${formatGridNumber(coord.z)}`,
    coord,
    extra: `玩家：${player.name}`,
    nonce: Date.now(),
  };
}

function MapContainer({ configRuntime, configLab = false }: { configRuntime?: ConfigPackageV3; configLab?: boolean }) {
  const application=getApplicationSettings();
  const WORLDS=application.worlds.filter(world=>world.enabled).map(world=>({id:world.id,name:world.label[application.preferences.language],center:world.center}));
  const PLAYER_FEATURE_ENABLED=moduleEnabled('players'),LINES_FEATURE_ENABLED=false;
  // The V3 lab is an isolated native-rendering environment.  Its configured
  // features must not be visually mixed with the old railway/landmark layers
  // or be filtered by the V1 rule-button registry.  The V1 lab and ordinary
  // map deliberately keep their existing paths unchanged.
  const nativeConfigLabActive = Boolean(configLab && isNativeConfigRevision(configRuntime?.contractRevision));
  const mapRef = useRef<HTMLDivElement>(null);
  const leafletMapRef = useRef<L.Map | null>(null);
  const projectionRef = useRef<DynmapProjection | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const measuringModuleRef = useRef<MeasuringModuleHandle | null>(null);
  const measurementToolsRef = useRef<MeasurementToolsHandle | null>(null);
  const mappingLauncherAnchorRef = useRef<HTMLDivElement | null>(null);
  const workspaceTransitionCoordinatorRef = useRef(new WorkspaceTransitionCoordinator());
  const [mapReady, setMapReady] = useState(false);
  const initialShareParseRef = useRef(consumeFeatureShareTargetFromLocation());
  const initialPendingShareRef = useRef<PendingShareTarget | null>(
    initialShareParseRef.current.kind === 'feature'
      ? { type: 'feature', target: normalizeShareWorld(initialShareParseRef.current.target) }
      : initialShareParseRef.current.kind === 'player'
        ? { type: 'player', target: normalizeShareWorld(initialShareParseRef.current.target) }
        : null
  );
  const shareTargetConsumedRef = useRef(false);
  const [shareTargetRevision, setShareTargetRevision] = useState(0);
  const [shareLinkMessage, setShareLinkMessage] = useState<string | null>(
    initialShareParseRef.current.kind === 'invalid-player'
      ? '无效世界或玩家ID'
      : initialShareParseRef.current.kind === 'invalid-feature'
        ? '无效世界或要素ID'
        : null
  );
  const [shareLookupState, setShareLookupState] = useState<ShareLookupState | null>(
    initialPendingShareRef.current ? createShareLookupState(initialPendingShareRef.current) : null
  );

  // 从 cookie 读取初始设置；分享链接中的 world 优先，避免先进入 cookie 世界再切换。
  const savedSettings = loadMapSettings();
  const [currentWorld, setCurrentWorld] = useState(() => enabledApplicationWorldId(normalizeRuleSourceWorldId(initialPendingShareRef.current?.target.worldId ?? savedSettings?.currentWorld ?? applicationWorld('').id)));

  const applyShareParseResult = useCallback((result: ShareParseResult) => {
    if (result.kind === 'none') return;

    if (result.kind === 'invalid-player') {
      initialPendingShareRef.current = null;
      shareTargetConsumedRef.current = true;
      setShareLookupState(null);
      setShareLinkMessage('无效世界或玩家ID');
      return;
    }

    if (result.kind === 'invalid-feature') {
      initialPendingShareRef.current = null;
      shareTargetConsumedRef.current = true;
      setShareLookupState(null);
      setShareLinkMessage('无效世界或要素ID');
      return;
    }

    const pending: PendingShareTarget = result.kind === 'player'
      ? { type: 'player', target: normalizeShareWorld(result.target) }
      : { type: 'feature', target: normalizeShareWorld(result.target) };
    if(!application.worlds.some(world=>world.id===pending.target.worldId&&world.enabled)){setShareLinkMessage('分享链接的世界未启用或不存在。');return;}
    initialPendingShareRef.current = pending;
    shareTargetConsumedRef.current = false;
    setShareLinkMessage(null);
    setShareLookupState(createShareLookupState(pending));
    setCurrentWorld(pending.target.worldId);
    setShareTargetRevision((revision) => revision + 1);
  }, []);

  const [showRailway, setShowRailway] = useState(false);
  const [showLandmark, setShowLandmark] = useState(false);
  const [showPlayers, setShowPlayers] = useState(
    PLAYER_FEATURE_ENABLED && (savedSettings?.showPlayers ?? true)
  );
  const [dimBackground, setDimBackground] = useState(savedSettings?.dimBackground ?? false);
  const [mapStyle, setMapStyle] = useState<MapStyle>(savedSettings?.mapStyle ?? 'default');
  const [showNavigation, setShowNavigation] = useState(false);
  const [showAttributeQuery, setShowAttributeQuery] = useState(false);
  const [showLinesPage, setShowLinesPage] = useState(false);
  const [showPlayersPage, setShowPlayersPage] = useState(false);
  const [showAbout, setShowAbout] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [reviewAccessBlockedMessage, setReviewAccessBlockedMessage] = useState<string | null>(null);
  const [showPublicReleaseRecords, setShowPublicReleaseRecords] = useState(false);
  const [rulePanelCollapsed, setRulePanelCollapsed] = useState(false);
  const [modePanelCollapsed, setModePanelCollapsed] = useState(false);
  const [mobileActivePanel, setMobileActivePanel] = useState<MobilePanelKey>(null);
  const [mobileQuickPanel, setMobileQuickPanel] = useState<MobileQuickPanelKey>(null);
  const [mobileSheetCollapsed, setMobileSheetCollapsed] = useState(false);
  const [mobileSheetHidden, setMobileSheetHidden] = useState(false);
  const [mobileSheetOffset, setMobileSheetOffset] = useState(0);
  const [selectedRuleFeature, setSelectedRuleFeature] = useState<FeatureRecord | null>(null);
  const [selectedRuleClassCode, setSelectedRuleClassCode] = useState<string | null>(null);
  const [navigationInitialEndPoint, setNavigationInitialEndPoint] = useState<NavigationInitialPoint | null>(null);

  const [mobileFeatureJson, setMobileFeatureJson] = useState<{ title: string; jsonText: string; filename: string } | null>(null);
  const [mobileFeatureShare, setMobileFeatureShare] = useState<FeatureSharePayload | null>(null);
  const [mobileFloorPanelState, setMobileFloorPanelState] = useState<{
    visible: boolean;
    buildingName: string;
    floorOptions: Array<{ label: string; value: string }>;
    activeFloorIndex: number;
  }>({ visible: false, buildingName: '', floorOptions: [], activeFloorIndex: 0 });
  const [mobileFloorCollapsed, setMobileFloorCollapsed] = useState(false);
  const [mobileQuickDockHeight, setMobileQuickDockHeight] = useState(0);
  const suppressRuleFeatureCardOpenRef = useRef(false);
  const ensureRuleWorldLoaded = useRuleDataStore((s) => s.ensureWorldLoaded);
  const currentRuleDataset = useRuleDataStore((s) => s.datasets[currentWorld]);
  const loadedRuleDatasets = useRuleDataStore((s) => s.datasets);
  const mountedRuleRecords = useMemo(() => Object.values(loadedRuleDatasets).flatMap((dataset) => dataset?.features ?? []), [loadedRuleDatasets]);
  const openConfigStudio = useCallback(() => {
    try {
      sessionStorage.setItem('cairnmap-config-studio-mounted-records', JSON.stringify(mountedRuleRecords));
    } catch {
      // A full-page workspace must not retain the live map merely because a
      // browser declined a transient data snapshot.
    }
    const target = new URL(window.location.href);
    target.searchParams.set('workspace', 'config-studio');
    window.location.assign(target.toString());
  }, [mountedRuleRecords]);
  const openConfigLab = useCallback(() => {
    const target = new URL(window.location.href);
    target.searchParams.set('workspace', 'config-lab');
    window.location.assign(target.toString());
  }, []);
  const currentRulePending = useRuleDataStore((s) => s.pending[currentWorld]);
  const isGlobalLoading = useLoadingStore((s) => s.isLoading);
  const activeRuleWorldId = useLoadingStore((s) => s.activeRuleWorldId);
  const measuringModuleState = useFeatureModuleStore((s) => s.modules.measuring);
  const reviewModuleState = useFeatureModuleStore((s) => s.modules.review);
  const legacyModuleState = useFeatureModuleStore((s) => s.modules.legacy);
  const featureDialogState = useFeatureModuleStore((s) => s.dialog);
  const requestFeatureModuleActivation = useFeatureModuleStore((s) => s.requestModuleActivation);
  const featureModulesHydrated = useFeatureModuleStore((s) => s.hydrated);
  const measuringModuleLoaded = measuringModuleState.status === 'loaded';
  const reviewModuleLoaded = reviewModuleState.status === 'loaded';
  const legacyModuleLoaded = legacyModuleState.status === 'loaded';
  const [pendingWorkspaceAdmission, setPendingWorkspaceAdmission] = useState<WorkspaceTransition | null>(null);
  const [pendingLegacyAction, setPendingLegacyAction] = useState<null | 'railway-on' | 'landmark-on' | 'lines-page'>(null);
  const [measuringOpenSignal, setMeasuringOpenSignal] = useState(0);
  const [measurementToolsOpenSignal, setMeasurementToolsOpenSignal] = useState(0);

  const [stations, setStations] = useState<ParsedStation[]>([]);
  const [lines, setLines] = useState<ParsedLine[]>([]);
  const [landmarks, setLandmarks] = useState<ParsedLandmark[]>([]);
  const [players, setPlayers] = useState<Player[]>([]);
  const [playerSnapshotReadyWorld, setPlayerSnapshotReadyWorld] = useState<string | null>(null);
  const [routeHighlight, setRouteHighlight] = useState<RouteHighlightData | null>(null);
  const [showRouteHighlight] = useState(true);

// 是否存在可绘制的路线（用于隐藏图层/显示清除按钮）
  const hasRoute =
    routeHighlight?.styledSegments?.some(s => Array.isArray(s.coords) && s.coords.length >= 2) ?? false;
  const showRouteOverlay = hasRoute && showRouteHighlight;

  const [highlightedLine, setHighlightedLine] = useState<ParsedLine | null>(null);
  const [selectedPoint, setSelectedPoint] = useState<{
    type: 'station' | 'landmark';
    name: string;
    coord: Coordinate;
    station?: ParsedStation;
    landmark?: ParsedLandmark;
  } | null>(null);
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  const legacyRailSearchEnabled = legacyModuleLoaded && showRailway;
  const legacyLandmarkSearchEnabled = legacyModuleLoaded && showLandmark;
  const searchStations = legacyRailSearchEnabled ? stations : [];
  const searchLines = legacyRailSearchEnabled ? lines : [];
  const searchLandmarks = legacyLandmarkSearchEnabled ? landmarks : [];
  const [measuringCloseSignal, setMeasuringCloseSignal] = useState(0);
  const [measureToolsCloseSignal, setMeasureToolsCloseSignal] = useState(0);
  const [moduleMode, setModuleMode] = useState<CairnMapModuleMode>('runtime');
  const [activeWorkspace, setActiveWorkspace] = useState<WorkspaceKind>('runtime');
  const [workspaceTransitionPhase, setWorkspaceTransitionPhase] = useState<'idle' | 'awaiting-source-confirmation' | 'preparing-target'>('idle');
  // Mapping and review deliberately receive different React instances.  The
  // review instance is never a mode switch inside a live mapping instance,
  // which prevents Leaflet feature groups, drawing state and custom events
  // from crossing the two workflow boundaries.
  const [workspaceInstanceKey, setWorkspaceInstanceKey] = useState(() => `mapping-${crypto.randomUUID()}`);
  const [reviewSession, setReviewSession] = useState<ReviewPackageSession | null>(null);
  const [, setReviewWorkspaceDirty] = useState(false);
  const [pendingReviewPackage, setPendingReviewPackage] = useState<ReviewInboxItem | null>(null);
  const [publicReleaseRecordsRefreshSignal, setPublicReleaseRecordsRefreshSignal] = useState(0);

  // 测绘激活态：用于禁止导航图选点（由 MeasuringModule / MeasurementToolsModule 派发）
// 说明：临时挂载启用时，MeasuringModule 可能被迫处于 active，但此时仍允许导航图选点（只要 MeasurementToolsModule 未启用）
const measuringModuleActiveRef = useRef(false);
const measurementToolsActiveRef = useRef(false);

  const syncWorkspaceCoordinator = useCallback(() => {
    const snapshot = workspaceTransitionCoordinatorRef.current.snapshot();
    setActiveWorkspace(snapshot.active);
    setWorkspaceTransitionPhase(snapshot.phase);
    // During a pending admission the source may already have been unmounted.
    // Do not let its old identity remount until this transition resolves.
    if (snapshot.phase === 'idle') {
      setModuleMode(snapshot.active === 'review' ? 'review' : snapshot.active === 'runtime' ? 'runtime' : 'mapping');
    }
  }, []);

  const reportWorkspaceInactive = useCallback((workspace: Exclude<WorkspaceKind, 'runtime'>) => {
    workspaceTransitionCoordinatorRef.current.reportInactive(workspace);
    syncWorkspaceCoordinator();
  }, [syncWorkspaceCoordinator]);

const isTempRuleMountEnabled = useCallback(() => hasEnabledTemporaryRuleSources(), []);

useEffect(() => {
  if (PLAYER_FEATURE_ENABLED) return;

  setPlayers([]);
  setSelectedPlayer(null);
  setShowPlayers(false);
  setShowPlayersPage(false);
  setMobileActivePanel((prev) => (prev === 'players' ? null : prev));
}, []);

useEffect(() => {
  if (LINES_FEATURE_ENABLED) return;

  setShowLinesPage(false);
  setPendingLegacyAction((prev) => (prev === 'lines-page' ? null : prev));
}, []);

useEffect(() => {
  const handleRuntimeShareUrl = () => {
    applyShareParseResult(consumeFeatureShareTargetFromLocation());
  };

  window.addEventListener('hashchange', handleRuntimeShareUrl);
  window.addEventListener('popstate', handleRuntimeShareUrl);

  return () => {
    window.removeEventListener('hashchange', handleRuntimeShareUrl);
    window.removeEventListener('popstate', handleRuntimeShareUrl);
  };
}, [applyShareParseResult]);

useEffect(() => {
  const handler = (ev: Event) => {
    const ce = ev as CustomEvent<{ active?: boolean; source?: string }>;
    const active = Boolean(ce?.detail?.active);
    const source = String(ce?.detail?.source ?? '');
    if (source === 'MeasurementToolsModule') {
      const wasActive = measurementToolsActiveRef.current;
      measurementToolsActiveRef.current = active;
      if (wasActive && !active) reportWorkspaceInactive('measurement');
      return;
    }
    if (source === 'ReviewWorkspace') {
      // Review-layer manager closure is local to a loaded package. Its owner
      // explicitly decides whether the review sequence stays open, changes
      // workspace, or exits; an internal Leaflet cleanup must not demote the
      // entire review module to runtime.
      measuringModuleActiveRef.current = active;
      return;
    }
    if (source === 'MeasuringModule') {
      const wasActive = measuringModuleActiveRef.current;
      measuringModuleActiveRef.current = active;
      // A freshly admitted editor broadcasts its initial idle state before
      // the launcher opens. Only an actual active -> idle transition is a
      // close; otherwise the host immediately unmounts the admitted editor.
      if (wasActive && !active) {
        // A review editor uses the same core but must retain its own identity.
        reportWorkspaceInactive(activeWorkspace === 'review' ? 'review' : 'mapping');
      }
      return;
    }
    // 兜底：未知来源则视作 MeasuringModule
    const wasActive = measuringModuleActiveRef.current;
    measuringModuleActiveRef.current = active;
    if (wasActive && !active) reportWorkspaceInactive(activeWorkspace === 'review' ? 'review' : 'mapping');
  };
  window.addEventListener('ria:measuringActiveChanged', handler as any);
  return () => window.removeEventListener('ria:measuringActiveChanged', handler as any);
}, [activeWorkspace, reportWorkspaceInactive]);

  const activateLegacyAction = useCallback(async (action: 'railway-on' | 'landmark-on' | 'lines-page') => {
    if (action === 'lines-page' && !LINES_FEATURE_ENABLED) return;
    try {
      await ensureLegacyDataLoaded();
      if (action === 'railway-on') setShowRailway(true);
      else if (action === 'landmark-on') setShowLandmark(true);
      else if (action === 'lines-page' && LINES_FEATURE_ENABLED) setShowLinesPage(true);
    } catch (error) {
      console.warn('[legacy] 旧数据源加载失败：', error);
    } finally {
      setPendingLegacyAction(null);
    }
  }, []);

  useEffect(() => {
    if (!pendingLegacyAction || !legacyModuleLoaded) return;
    void activateLegacyAction(pendingLegacyAction);
  }, [activateLegacyAction, pendingLegacyAction, legacyModuleLoaded]);

  useEffect(() => {
    if (!pendingLegacyAction) return;
    if (featureDialogState.isOpen) return;
    if (legacyModuleLoaded) return;
    if (legacyModuleState.status === 'loading') return;
    setPendingLegacyAction(null);
  }, [pendingLegacyAction, featureDialogState.isOpen, legacyModuleLoaded, legacyModuleState.status]);

  const requestLegacyFeature = useCallback((action: 'railway-on' | 'landmark-on' | 'lines-page') => {
    if (action === 'lines-page' && !LINES_FEATURE_ENABLED) return;
    if (legacyModuleLoaded) {
      void activateLegacyAction(action);
      return;
    }
    setPendingLegacyAction(action);
    requestFeatureModuleActivation('legacy');
  }, [activateLegacyAction, legacyModuleLoaded, requestFeatureModuleActivation]);

  const handleOpenLegacyLinesPage = useCallback(() => {
    if (!LINES_FEATURE_ENABLED) return;
    requestLegacyFeature('lines-page');
  }, [requestLegacyFeature]);

  const clearReviewWorkspaceState = useCallback(() => {
    setReviewSession(null);
    setReviewWorkspaceDirty(false);
    setPendingReviewPackage(null);
  }, []);

  const failWorkspaceAdmission = useCallback((transition: WorkspaceTransition, message?: string) => {
    if (!workspaceTransitionCoordinatorRef.current.failTarget(transition.token)) return;
    setPendingWorkspaceAdmission(null);
    clearReviewWorkspaceState();
    setWorkspaceInstanceKey((value) => value + 1);
    setModuleMode('runtime');
    syncWorkspaceCoordinator();
    if (message) setReviewAccessBlockedMessage(message);
  }, [clearReviewWorkspaceState, syncWorkspaceCoordinator]);

  const activateWorkspaceTarget = useCallback(async (transition: WorkspaceTransition) => {
    const pending = workspaceTransitionCoordinatorRef.current.snapshot().pending;
    if (!pending || pending.token !== transition.token || pending.target !== transition.target) return;

    if (transition.target === 'review') {
      // Module admission has a deliberately narrow, fast authentication
      // boundary.  Role lookup is deferred to the review surfaces that need
      // it, while Dispatcher-backed operations remain server-authorized.
      const session = await openriamapGithubReviewAuth.getSession({ includeRoles: false });
      const stillPending = workspaceTransitionCoordinatorRef.current.snapshot().pending;
      if (!stillPending || stillPending.token !== transition.token) return;
      if (session.status !== 'authenticated') {
        const message = session.status === 'unavailable'
          ? (session.message ?? '身份服务暂时不可用，无法进入审核模块。')
          : (session.message ?? '需要先在设置中登录 GitHub 身份，才能进入审核模块。');
        failWorkspaceAdmission(transition, message);
        return;
      }
    }

    if (!workspaceTransitionCoordinatorRef.current.activateTarget(transition.token)) return;
    setPendingWorkspaceAdmission(null);
    setWorkspaceInstanceKey((value) => value + 1);
    if (transition.target === 'review') {
      setModuleMode('review');
    } else {
      clearReviewWorkspaceState();
      setModuleMode('mapping');
      if (transition.target === 'mapping') setMeasuringOpenSignal((value) => value + 1);
      else setMeasurementToolsOpenSignal((value) => value + 1);
    }
    syncWorkspaceCoordinator();
  }, [clearReviewWorkspaceState, failWorkspaceAdmission, syncWorkspaceCoordinator]);

  const requestWorkspaceEntry = useCallback(async (target: Exclude<WorkspaceKind, 'runtime'>) => {
    const extra=getApplicationSettings().modules.items.find(item=>item.id===target)?.exclusiveWith??[];if(extra.includes('navigation'))setShowNavigation(false);if(extra.includes('settings'))setShowSettings(false);if(extra.includes('search'))window.dispatchEvent(new CustomEvent('cairn:close-module',{detail:{id:'search'}}));
    const transition = workspaceTransitionCoordinatorRef.current.request(target);
    if (!transition) return;
    // A repeated fixed-entry click belongs to the already-mounted workspace.
    // It may toggle that workspace's launcher, but must not synthesize a new
    // open signal (which used to reset/force-open the mapping menu).
    if (transition.token === 0) {
      if (target === 'mapping') measuringModuleRef.current?.toggleLauncherMenu?.();
      if (target === 'measurement') void measurementToolsRef.current?.toggleLauncher?.();
      return;
    }
    syncWorkspaceCoordinator();

    if (transition.source !== 'runtime') {
      const sourceLabel = target === 'review' ? '启动审核模块' : target === 'mapping' ? '切换至测绘模块' : '切换至测量工具';
      const sourceClosed = transition.source === 'measurement'
        ? await (measurementToolsRef.current?.requestCloseAndClear(sourceLabel) ?? Promise.resolve(true))
        : await (measuringModuleRef.current?.requestCloseAndClear(sourceLabel) ?? Promise.resolve(true));
      if (!sourceClosed) {
        workspaceTransitionCoordinatorRef.current.cancel(transition.token);
        syncWorkspaceCoordinator();
        return;
      }
      if (!workspaceTransitionCoordinatorRef.current.confirmSourceCleared(transition.token)) return;
      // requestCloseAndClear has already disposed the source instance.  Do
      // not send a second close signal here: for review it can race the new
      // package injection and briefly remount the ordinary mapping workspace.
      if (transition.source === 'measurement') setMeasureToolsCloseSignal((value) => value + 1);
      if (transition.source === 'review') clearReviewWorkspaceState();
      // The source is now fully discarded.  Keep the target unmounted while
      // its code and identity admission are resolved.
      setModuleMode('runtime');
      setWorkspaceInstanceKey((value) => value + 1);
      syncWorkspaceCoordinator();
    }

    const moduleReady = target === 'review' ? reviewModuleLoaded : measuringModuleLoaded;
    if (!moduleReady) {
      setPendingWorkspaceAdmission(transition);
      if (target === 'review') {
        requestFeatureModuleActivation('review', measuringModuleLoaded
          ? {
              title: '需要下载审核分包',
              description: '审核分包尚未加载。确认后将下载并启用审核代码；审核包、图片、图层和草稿仍只保留在当前浏览器会话。',
            }
          : undefined);
      } else {
        requestFeatureModuleActivation('measuring');
      }
      return;
    }
    await activateWorkspaceTarget(transition);
  }, [activateWorkspaceTarget, clearReviewWorkspaceState, measuringModuleLoaded, requestFeatureModuleActivation, reviewModuleLoaded, syncWorkspaceCoordinator]);

  useEffect(()=>registerApplicationGuard(async()=>{
    if(workspaceTransitionCoordinatorRef.current.snapshot().phase!=='idle')return false;
    const reason='应用总体规则';
    const accepted=activeWorkspace==='measurement'?await (measurementToolsRef.current?.requestCloseAndClear(reason)??Promise.resolve(true)):activeWorkspace==='mapping'||activeWorkspace==='review'?await (measuringModuleRef.current?.requestCloseAndClear(reason)??Promise.resolve(true)):true;
    if(accepted){clearReviewWorkspaceState();if(activeWorkspace!=='runtime')workspaceTransitionCoordinatorRef.current.reportInactive(activeWorkspace);}
    return accepted;
  }),[activeWorkspace,clearReviewWorkspaceState]);

  async function openNavigation(){
    if(!moduleEnabled('navigation'))return;
    const exclusive=getApplicationSettings().modules.items.find(item=>item.id==='navigation')?.exclusiveWith??[];
    if(activeWorkspace!=='runtime'&&exclusive.includes(activeWorkspace)){
      const okay=activeWorkspace==='measurement'?await (measurementToolsRef.current?.requestCloseAndClear('启动导航')??Promise.resolve(true)):await (measuringModuleRef.current?.requestCloseAndClear('启动导航')??Promise.resolve(true));
      if(!okay)return;workspaceTransitionCoordinatorRef.current.reportInactive(activeWorkspace);clearReviewWorkspaceState();syncWorkspaceCoordinator();
    }
    setShowNavigation(true);
  }
  const requestMeasuringModuleEntry = useCallback((target: 'measuring' | 'mtools') => {
    if(!moduleEnabled(target==='measuring'?'mapping':'measurement'))return;
    void requestWorkspaceEntry(target === 'measuring' ? 'mapping' : 'measurement');
  }, [requestWorkspaceEntry]);

  useEffect(() => {
    try {
      if (!featureModulesHydrated || !mapReady) return;
      const retry = sessionStorage.getItem('ria_feature_module_retry_v1');
      const target = sessionStorage.getItem('ria_feature_module_pending_tool_v1');
      if (!retry) return;
      sessionStorage.removeItem('ria_feature_module_retry_v1');
      sessionStorage.removeItem('ria_feature_module_pending_tool_v1');
      if (retry === 'review' && target === 'review') void requestWorkspaceEntry('review');
      else if (retry === 'measuring' && (target === 'measuring' || target === 'mtools')) requestMeasuringModuleEntry(target);
    } catch { /* optional session storage */ }
  }, [featureModulesHydrated, mapReady, requestMeasuringModuleEntry, requestWorkspaceEntry]);

  useEffect(() => {
    try {
      if (pendingWorkspaceAdmission) {
        const target = pendingWorkspaceAdmission.target;
        sessionStorage.setItem('ria_feature_module_pending_tool_v1', target === 'mapping' ? 'measuring' : target === 'measurement' ? 'mtools' : 'review');
      } else sessionStorage.removeItem('ria_feature_module_pending_tool_v1');
    } catch { /* optional session storage */ }
  }, [pendingWorkspaceAdmission]);

  const requestReviewModuleEntry = useCallback(() => {
    if(!moduleEnabled('review'))return;
    void requestWorkspaceEntry('review');
  }, [requestWorkspaceEntry]);

  const closeReviewModule = useCallback(async () => {
    if (activeWorkspace !== 'review') return true;
    const ok = await (measuringModuleRef.current?.requestCloseAndClear?.('关闭则为退出审核模块') ?? Promise.resolve(true));
    if (!ok) return false;
    clearReviewWorkspaceState();
    setWorkspaceInstanceKey((value) => value + 1);
    workspaceTransitionCoordinatorRef.current.reportInactive('review');
    syncWorkspaceCoordinator();
    return true;
  }, [activeWorkspace, clearReviewWorkspaceState, syncWorkspaceCoordinator]);

  // Closing the layer manager must not close the surrounding review sequence:
  // reviewers may continue inspecting the package detail and status board.
  const closeReviewWorkspace = useCallback(() => {
    clearReviewWorkspaceState();
    setWorkspaceInstanceKey((value) => value + 1);
  }, [clearReviewWorkspaceState]);

  // The package-detail panel is the lifecycle owner of a loaded review
  // workspace.  Closing that upstream panel therefore asks the editor to
  // perform its normal (simple/dirty) teardown before its cache is released.
  const closeBoundReviewWorkspace = useCallback(async () => {
    if (!reviewSession) return true;
    const closed = await (measuringModuleRef.current?.requestCloseAndClear?.('关闭审核包详情') ?? Promise.resolve(true));
    if (!closed) return false;
    clearReviewWorkspaceState();
    setWorkspaceInstanceKey((value) => value + 1);
    return true;
  }, [clearReviewWorkspaceState, reviewSession]);

  useEffect(() => {
    const requestExit = () => closeReviewModule();
    window.addEventListener('ria:reviewExitRequested', requestExit);
    return () => window.removeEventListener('ria:reviewExitRequested', requestExit);
  }, [closeReviewModule]);

  const loadReviewPackageIntoWorkspace = useCallback(async (item: ReviewInboxItem) => {
    if (activeWorkspace !== 'review' || !reviewModuleLoaded) return false;
    // Replacing a package must keep the review editor mounted.  Its own
    // package-injection path atomically clears old layers after this
    // confirmation; closing/re-keying it here was the cause of the review
    // panel disappearing and a MappingWorkspace appearing in its place.
    const ok = await (measuringModuleRef.current?.confirmReviewPackageReplacement?.('切换审核包') ?? Promise.resolve(true));
    if (!ok) return false;
    setReviewSession(createReviewPackageSession(item));
    setReviewWorkspaceDirty(false);
    setPendingReviewPackage(item);
    return true;
  }, [activeWorkspace, reviewModuleLoaded]);

  const handleReviewSave = useCallback(async (artifact: ReviewWorkspaceSaveArtifact) => {
    const context = reviewSession?.submissionContext;
    if (!reviewSession?.packageId || !context) {
      throw new Error('review-revision-context-missing');
    }
    if (context.submissionId !== reviewSession.packageId) {
      throw new Error('review-revision-context-invalid');
    }
    const saved = await uploadRiaReviewRevision({
      ...artifact,
      submissionId: context.submissionId,
      revisionCount: context.revisionCount,
      expectedStateVersion: context.stateVersion,
    });
    setReviewSession((prev) => prev && prev.packageId === saved.submissionId
      ? {
          ...prev,
          status: 'saved_remote',
          dirty: false,
          updatedAt: new Date().toISOString(),
          submissionContext: {
            ...prev.submissionContext!,
            revisionId: saved.revisionId,
            revisionCount: saved.revisionCount,
            stateVersion: saved.stateVersion,
            packageName: artifact.packageName,
          },
        }
      : prev);
    setReviewWorkspaceDirty(false);
  }, [reviewSession]);

  useEffect(() => {
    if (!pendingWorkspaceAdmission) return;
    const desiredState = pendingWorkspaceAdmission.target === 'review' ? reviewModuleState : measuringModuleState;
    if (desiredState.status === 'loaded') {
      void activateWorkspaceTarget(pendingWorkspaceAdmission);
      return;
    }
    if (desiredState.status === 'loading') return;
    if (featureDialogState.isOpen && featureDialogState.moduleKey === (pendingWorkspaceAdmission.target === 'review' ? 'review' : 'measuring')) return;
    // A declined or failed bundle prompt cannot leave the source half-closed
    // or manufacture a target mode.  The original source was only retained
    // when its own confirmation was cancelled above.
    failWorkspaceAdmission(pendingWorkspaceAdmission);
  }, [activateWorkspaceTarget, failWorkspaceAdmission, featureDialogState.isOpen, featureDialogState.moduleKey, measuringModuleState, pendingWorkspaceAdmission, reviewModuleState]);

  useEffect(() => {
    if (moduleMode !== 'review' || !reviewModuleLoaded || !pendingReviewPackage) return;
    const item = pendingReviewPackage;
    const timer = window.setTimeout(() => {
      window.dispatchEvent(new CustomEvent('ria:reviewLoadPackageIntoWorkspace', { detail: item }));
      setPendingReviewPackage(null);
    }, 0);
    return () => window.clearTimeout(timer);
  }, [moduleMode, pendingReviewPackage, reviewModuleLoaded]);


  // 规则图层“分组开关”（按 world 维度持久化）
  const { activeButtonIds: activeRuleButtonIds, toggle: toggleRuleButton } = useRuleButtonState(currentWorld);

  const ruleResolveFeatureByIdRef = useRef<any>(undefined);
  const ruleTriggerLabelClickRef = useRef<any>(undefined);

  const closeMobileSheet = useCallback(() => {
    suppressRuleFeatureCardOpenRef.current = false;
    setMobileActivePanel(null);
    setMobileSheetCollapsed(false);
    setMobileSheetHidden(false);
    setHighlightedLine(null);
    setSelectedPoint(null);
    setSelectedPlayer(null);
    setSelectedRuleFeature(null);
    setSelectedRuleClassCode(null);
    setMobileFeatureJson(null);
    setMobileFeatureShare(null);
    setNavigationInitialEndPoint(null);
    window.dispatchEvent(new CustomEvent('ria:ruleFeatureCardClose'));
  }, []);

  const openMobilePanel = useCallback((panel: MobilePanelKey) => {
    suppressRuleFeatureCardOpenRef.current = false;
    setMobileQuickPanel(null);
    setMobileSheetHidden(false);
    setMobileSheetCollapsed(false);
    setHighlightedLine(null);
    setSelectedPoint(null);
    setSelectedPlayer(null);
    setSelectedRuleFeature(null);
    setSelectedRuleClassCode(null);
    setMobileFeatureJson(null);
    setMobileFeatureShare(null);
    setNavigationInitialEndPoint(null);
    window.dispatchEvent(new CustomEvent('ria:ruleFeatureCardClose'));
    setMobileActivePanel((prev) => (prev === panel ? null : panel));
  }, []);

  // The authenticated review workbench can direct users to the public record
  // without rendering that record inside its own stacking context.
  useEffect(() => {
    const open = () => {
      if (window.matchMedia('(max-width: 639px)').matches) {
        suppressRuleFeatureCardOpenRef.current = false;
        setMobileQuickPanel(null);
        setMobileSheetHidden(false);
        setMobileSheetCollapsed(false);
        setMobileActivePanel('releaseRecords');
        return;
      }
      setShowPublicReleaseRecords(true);
    };
    window.addEventListener('ria:open-public-release-record', open);
    return () => window.removeEventListener('ria:open-public-release-record', open);
  }, []);

  const toggleMobileSheetCollapsed = useCallback(() => {
    setMobileSheetHidden(false);
    setMobileSheetCollapsed((prev) => !prev);
  }, []);

  const toggleMobileQuickPanel = useCallback((panel: MobileQuickPanelKey) => {
    setMobileQuickPanel((prev) => (prev === panel ? null : panel));
  }, []);

  useEffect(() => {
    const sameFeature = (a: any, b: any) => {
      const auid = String(a?.uid ?? '');
      const buid = String(b?.uid ?? '');
      if (auid || buid) return auid === buid;
      return a === b;
    };

    const handler = (ev: Event) => {
      const detail = (ev as CustomEvent<any>).detail ?? {};
      const nextFeature = detail.open ? (detail.feature ?? null) : null;
      ruleResolveFeatureByIdRef.current = detail.resolveFeatureById;
      ruleTriggerLabelClickRef.current = detail.onTryTriggerLabelClickById;

      if (suppressRuleFeatureCardOpenRef.current) {
        if (!detail.open) {
          suppressRuleFeatureCardOpenRef.current = false;
          setSelectedRuleFeature(null);
          setSelectedRuleClassCode(null);
        }
        return;
      }

      setSelectedRuleClassCode(detail.classCode ? String(detail.classCode) : null);
      setSelectedRuleFeature((prev) => {
        const changed = !sameFeature(prev, nextFeature);
        if (detail.open && (changed || !prev)) {
          setMobileQuickPanel(null);
          setMobileSheetHidden(false);
          setMobileSheetCollapsed(false);
          if (mobileActivePanel !== 'featureJson' && mobileActivePanel !== 'featureShare') setMobileActivePanel(null);
        }
        return nextFeature;
      });
    };

    window.addEventListener('ria:ruleFeatureCardState', handler as any);
    return () => window.removeEventListener('ria:ruleFeatureCardState', handler as any);
  }, [mobileActivePanel]);


  useEffect(() => {
    const handler = (ev: Event) => {
      const detail = (ev as CustomEvent<any>).detail ?? {};
      setMobileFloorPanelState({
        visible: Boolean(detail.visible),
        buildingName: String(detail.buildingName ?? ''),
        floorOptions: Array.isArray(detail.floorOptions) ? detail.floorOptions : [],
        activeFloorIndex: Number.isInteger(detail.activeFloorIndex) ? detail.activeFloorIndex : 0,
      });
    };

    window.addEventListener('ria:mobileFloorPanelState', handler as EventListener);
    return () => window.removeEventListener('ria:mobileFloorPanelState', handler as EventListener);
  }, []);

  const handleMobileFloorSelect = useCallback((index: number) => {
    window.dispatchEvent(new CustomEvent('ria:mobileFloorSelect', { detail: { index } }));
  }, []);

  useEffect(() => {
    const handler = (ev: Event) => {
      const detail = (ev as CustomEvent<any>).detail ?? {};
      const feature = detail.feature as FeatureRecord | null | undefined;
      if (!feature) return;

      const point = buildNavigationInitialPointFromFeature(feature, String(detail.title ?? ''));
      setNavigationInitialEndPoint(point);

      const isMobile = typeof window !== 'undefined' && window.matchMedia('(max-width: 639px)').matches;
      if (isMobile) {
        suppressRuleFeatureCardOpenRef.current = true;
        setMobileQuickPanel(null);
        setMobileFeatureJson(null);
        setMobileFeatureShare(null);
        setSelectedRuleFeature(null);
        setSelectedRuleClassCode(null);
        setMobileActivePanel('navigation');
        setMobileSheetHidden(false);
        setMobileSheetCollapsed(false);
        window.dispatchEvent(new CustomEvent('ria:ruleFeatureCardClose'));
        return;
      }

      void openNavigation();
    };

    window.addEventListener('ria:featureCardNavigate', handler as EventListener);
    return () => window.removeEventListener('ria:featureCardNavigate', handler as EventListener);
  }, []);

  // 关闭"铁路图层"时，同时隐藏线路高亮与详情卡片，避免看起来"图层控制不生效"
  useEffect(() => {
    if (!showRailway) {
      setHighlightedLine(null);
    }
  }, [showRailway]);

  // 控制背景淡化
  useEffect(() => {
    const tilePane = document.querySelector('.leaflet-tile-pane');
    if (tilePane) {
      if (dimBackground) {
        tilePane.classList.add('dimmed');
      } else {
        tilePane.classList.remove('dimmed');
      }
    }
  }, [dimBackground]);

  // 地图风格切换
  useEffect(() => {
    const map = leafletMapRef.current;
    if (!map || !mapReady) return;

    // 移除旧瓦片图层
    if (tileLayerRef.current) {
      tileLayerRef.current.remove();
    }

// 添加新瓦片图层
let newTileLayer: L.TileLayer;


const tileLayerOptions = { ...TILE_ZOOM_BOUNDS };

if (mapStyle === 'sketch') {
  newTileLayer = createSketchTileLayer(currentWorld, 'flat', tileLayerOptions);
} else if (mapStyle === 'watercolor') {
  newTileLayer = createWatercolorTileLayer(currentWorld, 'flat', tileLayerOptions);
} else {
  newTileLayer = createDynmapTileLayer(currentWorld, 'flat', tileLayerOptions);
}


    newTileLayer.addTo(map);
    tileLayerRef.current = newTileLayer;
  }, [mapStyle, mapReady, currentWorld]);

  // 保存地图设置到 cookie
  useEffect(() => {
    saveMapSettings({
      currentWorld,
      showRailway,
      showLandmark,
      showPlayers,
      dimBackground,
      mapStyle,
    });
  }, [currentWorld, showRailway, showLandmark, showPlayers, dimBackground, mapStyle]);

  // Legacy 旧数据源改为按需加载；默认进入页面不再预加载旧 railway / landmark。
  const { getWorldData, isLoaded: dataLoaded } = useDataStore();

  // 切换世界时从缓存加载数据
  useEffect(() => {
    if (!dataLoaded) return;

    const worldData = getWorldData(currentWorld);
    if (worldData) {
      setLines(worldData.lines);
      setStations(worldData.stations);
      setLandmarks(worldData.landmarks);
    }

// 玩家数据由独立轮询 effect 统一维护，避免 PlayerLayer / MapContainer 重复请求。

    // 清除之前的路径
    setRouteHighlight(null);
    setHighlightedLine(null);

  }, [currentWorld, dataLoaded, getWorldData]);

  useEffect(() => {
    if (!PLAYER_FEATURE_ENABLED || !mapReady) return;

    let cancelled = false;
    let timerId: number | null = null;
    let inFlight = false;
    let consecutiveFailures = 0;
    let lastWarningAt = 0;
    const worldId = currentWorld;

    const loadPlayers = async () => {
      if (inFlight || cancelled) return;
      inFlight = true;
      try {
        const result = await fetchPlayersDetailed(worldId);
        if (cancelled) return;
        if (result.error) {
          consecutiveFailures += 1;
          // A transient 502 must not erase the last valid player snapshot or
          // flood developer tools. Log no more than once per minute.
          if (Date.now() - lastWarningAt >= 60_000) {
            lastWarningAt = Date.now();
            console.warn('[MapContainer] 玩家信息读取暂时失败；保留上一次成功结果并稍后重试：', result.error);
          }
        } else {
          consecutiveFailures = 0;
          setPlayers(result.players);
          setPlayerSnapshotReadyWorld(worldId);
        }
      } finally {
        inFlight = false;
        if (!cancelled) {
          timerId = window.setTimeout(() => { void loadPlayers(); }, nextPlayerPollDelayMs(consecutiveFailures));
        }
      }
    };

    setPlayers([]);
    setSelectedPlayer(null);
    setPlayerSnapshotReadyWorld(null);
    void loadPlayers();

    return () => {
      cancelled = true;
      if (timerId !== null) window.clearTimeout(timerId);
    };
  }, [currentWorld, mapReady]);

  useEffect(() => {
    setSelectedPlayer((prev) => {
      if (!prev) return prev;
      const latest = players.find((p) => (prev.account && p.account === prev.account) || p.name === prev.name);
      return latest ?? prev;
    });
  }, [players]);

  // Rule 数据：按当前 world 单独加载，使用版本校验缓存。
  useEffect(() => {
    if (!mapReady) return;
    void ensureRuleWorldLoaded(currentWorld).catch((err) => {
      console.warn('[MapContainer] ensureRuleWorldLoaded failed:', err);
    });
  }, [currentWorld, ensureRuleWorldLoaded, mapReady]);

  // 搜索结果选中处理
  // 说明：过去仅用 uid 去重会在“先选 STB/其它要素，再选规则要素”时产生偶发短路。
  // 这里改为 token + 时间窗的方式：仅在极短时间内重复点击同一目标时跳过缩放。
  const lastSearchTokenRef = useRef<string | null>(null);
  const lastSearchAtRef = useRef<number>(0);

  const handleSearchSelect = useCallback((result: SearchResult) => {
    const map = leafletMapRef.current;
    const proj = projectionRef.current;
    if (!map || !proj) return;

    // 防止上一轮 setView/fitBounds 的动画仍在进行导致本次 fitBounds 偶发不生效
    map.stop();

    if (result.type === 'player') {
      lastSearchTokenRef.current = result.type ? `${result.type}:` : null;
      lastSearchAtRef.current = Date.now();
      if (!result.coord) return;

      const player = result.playerData
        ? { ...result.playerData, x: result.coord.x, y: result.coord.y, z: result.coord.z }
        : null;
      if (player) {
        setMobileQuickPanel(null);
        setMobileSheetHidden(false);
        setMobileSheetCollapsed(false);
        setSelectedPlayer(player);
        setSelectedPoint(null);
        setHighlightedLine(null);
        setSelectedRuleFeature(null);
        setSelectedRuleClassCode(null);
      }

      const latLng = proj.locationToLatLng(result.coord.x, result.coord.y, result.coord.z);
      map.setView(latLng, 5);
      return;
    }

    // 旧数据（站点/地标/线路）保持原行为：中心到点位 & zoom=5
    if (result.type !== 'rule') {
      // 切换到非 rule 结果后，允许下一次再次选择同一 rule 时重新聚焦/缩放
      lastSearchTokenRef.current = result.type ? `${result.type}:` : null;
      lastSearchAtRef.current = Date.now();
      if (!result.coord) return;
      const latLng = proj.locationToLatLng(result.coord.x, result.coord.y, result.coord.z);
      map.setView(latLng, 5);
      return;
    }

    // Rules：
    // 1) 若对应图层按钮未开启，先自动开启（避免“搜索到但不显示/不可点”）
    // 2) 聚焦到 bbox 中心，并在需要时缩放到能包裹 bbox 的最小 zoom
    // 3) 发事件交给 RuleDrivenLayer 打开信息卡
    const r = result.ruleRecord;

    // ✅ 避免重复点击同一要素时不断触发视图缩放（会导致“二次放大偏离预期”）
    // - 仅在很短时间内重复点击同一 token 时跳过缩放；否则始终允许重新聚焦
    const uid = String(r?.uid ?? '').trim();
    const token = uid ? `rule:${uid}` : 'rule:';
    const now = Date.now();
    const isSameQuickRepeat = lastSearchTokenRef.current === token && (now - lastSearchAtRef.current) < 600;
    lastSearchTokenRef.current = token;
    lastSearchAtRef.current = now;

    if (r) {
      const needIds = getMatchingRuleButtonIds(r);
      if (needIds.length) {
        for (const id of needIds) {
          if (!activeRuleButtonIds.includes(id)) toggleRuleButton(id);
        }
      }
    }

    if (!isSameQuickRepeat) {
      // bbox 缩放：优先用 record.coords3 计算（线/面）
      // 关键：若有 bbox，则只做 fitBounds（不要先 setView 再 fitBounds），避免动画竞争导致偶发失效
      let didFit = false;
      if (r && Array.isArray(r.coords3) && r.coords3.length > 1) {
        const fallbackY = (result.coord?.y ?? 64) as any;
        const pts = r.coords3
          .map((p: any) => {
            const y = Number.isFinite(p?.y) ? p.y : fallbackY;
            const ll = proj.locationToLatLng(p.x, y, p.z);
            return ll;
          })
          .filter((ll: any) => ll && Number.isFinite(ll.lat) && Number.isFinite(ll.lng));

        if (pts.length >= 2) {
          const bounds = L.latLngBounds(pts);
          if ((bounds as any)?.isValid?.() ? (bounds as any).isValid() : true) {
            didFit = true;
            // 终止上一轮动画后，在下一帧执行 fitBounds，提升稳定性
            requestAnimationFrame(() => {
              map.stop();
              map.fitBounds(bounds, { animate: true, padding: [16, 16] });
            });
          }
        }
      }

      // 点要素/无 bbox：回退为 setView
      if (!didFit && result.coord) {
        const latLng = proj.locationToLatLng(result.coord.x, result.coord.y, result.coord.z);
        requestAnimationFrame(() => {
          map.stop();
          map.setView(latLng, 5, { animate: true });
        });
      }
    }

    if (r?.uid) {
      window.dispatchEvent(new CustomEvent('ria:ruleFeatureSelect', { detail: { uid: r.uid } }));
    }
  }, [activeRuleButtonIds, toggleRuleButton]);

  useEffect(() => {
    const pending = initialPendingShareRef.current;
    if (!pending || shareTargetConsumedRef.current) return;
    if (!mapReady || currentWorld !== pending.target.worldId) return;

    const currentRuleWorldReadyForShare = Boolean(currentRuleDataset) && !currentRulePending && !isGlobalLoading && activeRuleWorldId !== currentWorld;
    if (pending.type === 'feature' && !currentRuleWorldReadyForShare) {
      setShareLookupState(createShareLookupState(pending, 'waiting-map-ready', 0, 1));
      return;
    }

    const playerSnapshotReadyForShare = playerSnapshotReadyWorld === pending.target.worldId;
    if (pending.type === 'player' && !playerSnapshotReadyForShare) {
      setShareLookupState(createShareLookupState(pending, 'waiting-player-list', 0, 1));
      return;
    }

    let cancelled = false;
    let timer: number | null = null;
    let waitingAttempts = 0;
    let searchAttempts = 0;

    const clearTimer = () => {
      if (timer !== null) {
        window.clearTimeout(timer);
        timer = null;
      }
    };

    const finishShare = () => {
      shareTargetConsumedRef.current = true;
      initialPendingShareRef.current = null;
      setShareLookupState(null);
      clearTimer();
    };

    const finishAsInvalid = (message: string) => {
      if (cancelled || shareTargetConsumedRef.current) return;
      finishShare();
      setShareLinkMessage(message);
      console.warn('[share-link] 未找到分享链接对应的目标：', pending);
    };

    const scheduleNextTry = (fn: () => void) => {
      timer = window.setTimeout(fn, SHARE_LOOKUP_RETRY_MS);
    };

    const tryOpenSharedFeature = () => {
      if (cancelled || shareTargetConsumedRef.current || pending.type !== 'feature') return;
      const target = pending.target;

      const pool = getRuleSearchPool(target.worldId);
      if (pool.length === 0) {
        waitingAttempts += 1;
        setShareLookupState(createShareLookupState(
          pending,
          'waiting-pool',
          waitingAttempts,
          SHARE_LOOKUP_WAIT_POOL_ATTEMPTS,
        ));

        if (waitingAttempts < SHARE_LOOKUP_WAIT_POOL_ATTEMPTS) {
          scheduleNextTry(tryOpenSharedFeature);
          return;
        }

        finishAsInvalid('无效世界或要素ID');
        return;
      }

      searchAttempts += 1;
      setShareLookupState(createShareLookupState(
        pending,
        'searching-feature',
        searchAttempts,
        SHARE_LOOKUP_SEARCH_ATTEMPTS,
      ));

      const record = findRuleByShareTarget(pool, target);
      if (record) {
        const buildingNameIndex = buildBuildingNameIndex(pool);
        const display = getRuleDisplayName(record);
        const result: SearchResult = {
          type: 'rule',
          name: display.name || display.rawName || target.featureId,
          coord: getRuleCenterCoord(record),
          extra: getRuleCategoryLabelWithParent(record, buildingNameIndex),
          ruleRecord: record,
        };
        finishShare();
        handleSearchSelect(result);
        return;
      }

      if (searchAttempts < SHARE_LOOKUP_SEARCH_ATTEMPTS) {
        scheduleNextTry(tryOpenSharedFeature);
        return;
      }

      finishAsInvalid('无效世界或要素ID');
    };

    const tryOpenSharedPlayer = () => {
      if (cancelled || shareTargetConsumedRef.current || pending.type !== 'player') return;
      const target = pending.target;
      const wanted = normalizePlayerShareId(target.playerId);

      searchAttempts += 1;
      setShareLookupState(createShareLookupState(
        pending,
        'searching-player',
        searchAttempts,
        PLAYER_SHARE_LOOKUP_ATTEMPTS,
      ));

      const player = players.find((p) => {
        const account = normalizePlayerShareId(p.account);
        const name = normalizePlayerShareId(p.name);
        return account === wanted || name === wanted;
      }) ?? null;

      if (player) {
        finishShare();
        setShareLinkMessage(null);
        setMobileQuickPanel(null);
        setMobileSheetHidden(false);
        setMobileSheetCollapsed(false);
        setSelectedPlayer(player);
        setSelectedPoint(null);
        setHighlightedLine(null);
        setSelectedRuleFeature(null);
        setSelectedRuleClassCode(null);

        const map = leafletMapRef.current;
        const proj = projectionRef.current;
        if (map && proj) {
          map.stop();
          const latLng = proj.locationToLatLng(player.x, player.y, player.z);
          map.setView(latLng, 5, { animate: true });
        }
        return;
      }

      if (searchAttempts < PLAYER_SHARE_LOOKUP_ATTEMPTS) {
        scheduleNextTry(tryOpenSharedPlayer);
        return;
      }

      finishAsInvalid('无效世界或玩家ID');
    };

    timer = window.setTimeout(
      pending.type === 'player' ? tryOpenSharedPlayer : tryOpenSharedFeature,
      0,
    );

    return () => {
      cancelled = true;
      clearTimer();
    };
  }, [
    activeRuleWorldId,
    currentRuleDataset,
    currentRulePending,
    currentWorld,
    handleSearchSelect,
    isGlobalLoading,
    mapReady,
    playerSnapshotReadyWorld,
    players,
    shareTargetRevision,
  ]);


  // 线路选中处理 - 高亮线路并调整视图
  const handleLineSelect = useCallback((line: ParsedLine) => {
    if (!showRailway) setShowRailway(true);
    setMobileQuickPanel(null);
    setMobileSheetHidden(false);
    setMobileSheetCollapsed(false);
    setHighlightedLine(line);
    setRouteHighlight(null);  // 清除路径规划
    setSelectedPoint(null);  // 清除点位选中

    const map = leafletMapRef.current;
    const proj = projectionRef.current;
    if (!map || !proj || line.stations.length === 0) return;

    // 计算线路边界
    const bounds = L.latLngBounds(
      line.stations.map(s => proj.locationToLatLng(s.coord.x, s.coord.y || 64, s.coord.z))
    );
    map.fitBounds(bounds, { padding: [50, 50] });
  }, [showRailway]);

  // 站点点击处理
  const handleStationClick = useCallback((station: ParsedStation) => {
    setMobileQuickPanel(null);
    setMobileSheetHidden(false);
    setMobileSheetCollapsed(false);
    setSelectedPoint({
      type: 'station',
      name: station.name,
      coord: station.coord,
      station,
    });
    setHighlightedLine(null);
    setSelectedPlayer(null);

    const map = leafletMapRef.current;
    const proj = projectionRef.current;
    if (!map || !proj) return;
    const latLng = proj.locationToLatLng(station.coord.x, station.coord.y || 64, station.coord.z);
    map.setView(latLng, 5);
  }, []);

  // 地标点击处理
  const handleLandmarkClick = useCallback((landmark: ParsedLandmark) => {
    if (!landmark.coord) return;
    setMobileQuickPanel(null);
    setMobileSheetHidden(false);
    setMobileSheetCollapsed(false);
    setSelectedPoint({
      type: 'landmark',
      name: landmark.name,
      coord: landmark.coord,
      landmark,
    });
    setHighlightedLine(null);
    setSelectedPlayer(null);

    const map = leafletMapRef.current;
    const proj = projectionRef.current;
    if (!map || !proj) return;
    const latLng = proj.locationToLatLng(landmark.coord.x, landmark.coord.y || 64, landmark.coord.z);
    map.setView(latLng, 5);
  }, []);

  // 玩家点击处理
  const handlePlayerClick = useCallback((player: Player) => {
    setMobileQuickPanel(null);
    setMobileSheetHidden(false);
    setMobileSheetCollapsed(false);
    setSelectedPlayer(player);
    setSelectedPoint(null);
    setHighlightedLine(null);

    const map = leafletMapRef.current;
    const proj = projectionRef.current;
    if (!map || !proj) return;
    const latLng = proj.locationToLatLng(player.x, player.y, player.z);
    map.setView(latLng, 5);
  }, []);

  // 计算附近点位
  const getNearbyPoints = useCallback((coord: Coordinate, radius: number = 500) => {
    const getDistance = (a: Coordinate, b: Coordinate) => {
      const dx = a.x - b.x;
      const dz = a.z - b.z;
      return Math.sqrt(dx * dx + dz * dz);
    };

    const nearbyStations = stations
      .filter(s => getDistance(coord, s.coord) <= radius && getDistance(coord, s.coord) > 0)
      .sort((a, b) => getDistance(coord, a.coord) - getDistance(coord, b.coord))
      .slice(0, 5);

    const nearbyLandmarks = landmarks
      .filter(l => l.coord && getDistance(coord, l.coord) <= radius && getDistance(coord, l.coord) > 0)
      .sort((a, b) => getDistance(coord, a.coord!) - getDistance(coord, b.coord!))
      .slice(0, 5);

    return { nearbyStations, nearbyLandmarks };
  }, [stations, landmarks]);

  // 导航路径找到时的处理
const handleRouteFound = useCallback((route: RouteHighlightData | Array<{ coord: Coordinate }>) => {
  setHighlightedLine(null); // 清除线路高亮

  // 统一归一化为 RouteHighlightData
  let rh: RouteHighlightData | null = null;

  if (Array.isArray(route)) {
    const coords = route.map(p => p.coord).filter(Boolean);
    rh = coords.length >= 2 ? { styledSegments: [{ kind: 'generic', coords }] } : null;
  } else {
    rh = route;
  }

  setRouteHighlight(rh);

  // 计算边界并调整视图
  const map = leafletMapRef.current;
  const proj = projectionRef.current;
  if (!map || !proj || !rh?.styledSegments?.length) return;

  const allCoords: Coordinate[] = [];
  for (const seg of rh.styledSegments) {
    if (!Array.isArray(seg.coords)) continue;
    for (const c of seg.coords) allCoords.push(c);
  }
  if (allCoords.length === 0) return;

  const bounds = L.latLngBounds(
    allCoords.map(c => proj.locationToLatLng(c.x, c.y || 64, c.z))
  );
  map.fitBounds(bounds, { padding: [50, 50] });
}, []);


  // 世界切换处理
  const handleWorldChange = useCallback(async (worldId: string) => {
    const normalizedWorldId = normalizeRuleSourceWorldId(worldId);
    if(!application.worlds.some(world=>world.id===normalizedWorldId&&world.enabled))return;
    // 世界切换前默认触发“关闭测绘”。若用户不确认，则禁止切换。
    // 注意：必须在 setCurrentWorld 之前执行，否则会导致临时挂载/图层归属混乱。
    const ok = await (measuringModuleRef.current?.requestCloseAndClear?.('切换世界') ?? Promise.resolve(true));
    if (!ok) return;

    // 同步关闭“测量工具”（不需要二次确认）
    setMeasureToolsCloseSignal(v => v + 1);

    setCurrentWorld(normalizedWorldId);

    // 更新瓦片图层
    const map = leafletMapRef.current;
    if (!map) return;
    const crs=createDynmapCRS(getWorldConfig(normalizedWorldId));map.options.crs=crs;const proj=(crs as any).dynmapProjection as DynmapProjection;projectionRef.current=proj;

    // 移除旧瓦片图层
    if (tileLayerRef.current) {
      tileLayerRef.current.remove();
    }

    // 添加新瓦片图层（根据当前风格选择）
    let newTileLayer: L.TileLayer;
const tileLayerOptions = { ...TILE_ZOOM_BOUNDS };

if (mapStyle === 'sketch') {
  newTileLayer = createSketchTileLayer(normalizedWorldId, 'flat', tileLayerOptions);
} else if (mapStyle === 'watercolor') {
  newTileLayer = createWatercolorTileLayer(normalizedWorldId, 'flat', tileLayerOptions);
} else {
  newTileLayer = createDynmapTileLayer(normalizedWorldId, 'flat', tileLayerOptions);
}


    newTileLayer.addTo(map);
    tileLayerRef.current = newTileLayer;

    // 移动到新世界的中心点
    const world = WORLDS.find(w => w.id === normalizedWorldId);
    if (world) {
      const centerLatLng = proj.locationToLatLng(
        world.center.x,
        world.center.y,
        world.center.z
      );
      map.setView(centerLatLng, 2);
    }
  }, [mapStyle]);

  useEffect(() => {
    if (!mapRef.current || leafletMapRef.current) return;

    // 从 cookie 读取初始世界设置
    const savedWorld = enabledApplicationWorldId(normalizeRuleSourceWorldId(initialPendingShareRef.current?.target.worldId ?? loadMapSettings()?.currentWorld ?? applicationWorld('').id));

    // 创建 Dynmap CRS
    const crs = createDynmapCRS(getWorldConfig(savedWorld));
    const projection = (crs as any).dynmapProjection as DynmapProjection;
    projectionRef.current = projection;

    // 计算初始中心点 - 使用保存的世界，否则退回零洲
    const world = WORLDS.find(w => w.id === savedWorld) ?? WORLDS.find(w => w.id === 'zth') ?? WORLDS[0];
    if (!world) return;

    const centerLatLng = projection.locationToLatLng(
      Number(world.center.x),
      Number(world.center.y),
      Number(world.center.z)
    );

const minZoom = MAP_ZOOM_BOUNDS.minZoom;
const maxZoom = MAP_ZOOM_BOUNDS.maxZoom;

const map = L.map(mapRef.current, {
  crs: crs,
  center: centerLatLng,
  zoom: application.preferences.map.logicalInitialZoom+application.preferences.map.leafletOffset,
  scrollWheelZoom: application.preferences.map.scrollWheelZoom,
  doubleClickZoom: application.preferences.map.doubleClickZoom,
  dragging: application.preferences.map.dragging,
  minZoom,
  maxZoom,

  // 明确锁定“整数缩放”
  zoomSnap: 1,
  zoomDelta: 1,

  zoomControl: false,
  attributionControl: true
});





    // 添加缩放控件 - 仅桌面端使用 Leaflet 默认控件；移动端改为右侧自定义按钮
    const isDesktop = window.innerWidth >= 640;
    if (isDesktop) {
      L.control.zoom({ position: 'bottomright' }).addTo(map);
    }

    // 添加 Dynmap 瓦片图层 - 使用保存的世界和风格
    const savedMapStyle = loadMapSettings()?.mapStyle ?? 'default';
const tileLayerOptions = { ...TILE_ZOOM_BOUNDS };

let tileLayer: L.TileLayer;
if (savedMapStyle === 'sketch') {
  tileLayer = createSketchTileLayer(savedWorld, 'flat', tileLayerOptions);
} else if (savedMapStyle === 'watercolor') {
  tileLayer = createWatercolorTileLayer(savedWorld, 'flat', tileLayerOptions);
} else {
  tileLayer = createDynmapTileLayer(savedWorld, 'flat', tileLayerOptions);
}


    tileLayer.addTo(map);
    tileLayerRef.current = tileLayer;

    // 开发期：输出缩放/中心点对应的瓦片 URL，便于定位“缩放偏移”类问题
    if (import.meta.env.DEV) {
      const logTileDebug = () => {
        const layer = tileLayerRef.current as unknown as DynmapTileLayer | null;
        const proj = projectionRef.current;
        if (!layer || !proj || typeof (layer as any).getDynmapTileForLatLng !== 'function') return;
        const center = map.getCenter();
        const zoom = map.getZoom();
        const tile = (layer as any).getDynmapTileForLatLng(center, zoom);
        const mc = proj.latLngToLocation(center, 64);
        console.log('[tile-debug]', { zoom, tileZoom: tile.tileZoom, center, mc, tile: tile.info, url: tile.url });
      };
      map.on('zoomend moveend', logTileDebug);
      logTileDebug();
    }

    // 添加坐标显示控件
    const coordControl = new L.Control({ position: 'bottomleft' });
    coordControl.onAdd = function() {
      const div = L.DomUtil.create('div', 'coord-display');
      div.style.cssText = 'background: rgba(255,255,255,0.9); padding: 5px 10px; border-radius: 4px; font-family: monospace; font-size: 12px;';
      div.innerHTML = 'X: 0, Z: 0';
      return div;
    };
    coordControl.addTo(map);

    // 监听鼠标移动，更新坐标显示
const coordDiv = coordControl.getContainer?.() ?? document.querySelector('.coord-display');
let rafId: number | null = null;
let latestCoord: { x: number; z: number } | null = null;

const flushCoord = () => {
  if (!coordDiv || !latestCoord) return;
  coordDiv.innerHTML = `X: ${formatGridNumber(latestCoord.x)}, Z: ${formatGridNumber(latestCoord.z)}`;
  rafId = null;
};

    // 导航“图上选取”使用：由 MapContainer 统一派发地图点击事件
    // 注意：只派发世界坐标；具体吸附/写入由 NavigationPanel 处理
    map.on('click', (e: L.LeafletMouseEvent) => {
      try {
        // 禁用条件：测量工具启用时永远禁止；测绘(快捷/完整)启用时，若临时挂载未启用则禁止
        if (measurementToolsActiveRef.current) return;
        if (measuringModuleActiveRef.current && !isTempRuleMountEnabled()) return;
        const proj = projectionRef.current;
        if (!proj) return;
        const p = proj.latLngToLocation(e.latlng, 64);
        window.dispatchEvent(
          new CustomEvent<MapClickWorldPointEventDetail>('ria:mapClickWorldPoint', {
            detail: {
              worldId: currentWorld,
              point: { x: p.x, y: p.y, z: p.z },
            },
          })
        );
      } catch (err) {
        console.warn('[mapClickWorldPoint] dispatch failed', err);
      }
    });

const handleMouseMove = (e: L.LeafletMouseEvent) => {
  const proj = projectionRef.current;
  if (!proj) return;

  const worldCoord = proj.latLngToLocation(e.latlng, 64);

  // 与测绘控件保持一致：坐标显示也遵循“方块中心(.5)/方块边缘(.0)/自动(.5步进)”
  const snapped = snapWorldPointByMode({ x: worldCoord.x, z: worldCoord.z });
  latestCoord = snapped;

  if (rafId === null) {
    rafId = window.requestAnimationFrame(flushCoord);
  }
};

map.on('mousemove', handleMouseMove);


    leafletMapRef.current = map;
    setMapReady(true);

    // 清理函数
    return () => {
      map.off('mousemove', handleMouseMove);
      if (rafId !== null) window.cancelAnimationFrame(rafId);
      if (leafletMapRef.current) {
        leafletMapRef.current.remove();
        leafletMapRef.current = null;
      }
    };
  }, []);

  const mobileSheetTitle = highlightedLine
    ? '线路详情'
    : selectedPoint
      ? '点位详情'
      : selectedPlayer
        ? '玩家详情'
        : selectedRuleFeature
          ? '要素信息'
          : mobileActivePanel === 'navigation'
            ? '路径规划'
            : mobileActivePanel === 'attributeQuery'
              ? '按属性查询'
              : mobileActivePanel === 'players'
                ? '在线玩家'
                : mobileActivePanel === 'about'
                  ? '关于'
                : mobileActivePanel === 'settings'
                  ? '设置'
                  : mobileActivePanel === 'releaseRecords'
                    ? '发布记录'
                  : mobileActivePanel === 'featureJson'
                      ? 'JSON 详情'
                      : mobileActivePanel === 'featureShare'
                        ? '分享要素'
                        : '';

  const shouldShowMobileSheet = Boolean(highlightedLine || selectedPoint || selectedPlayer || selectedRuleFeature || mobileActivePanel);

  const renderMobileSheetContent = () => {
    if (highlightedLine) {
      return (
        <Suspense fallback={null}>
          <LazyLineDetailCard
            line={highlightedLine}
            onClose={() => setHighlightedLine(null)}
            onStationClick={(_name: string, coord: Coordinate) => {
              const map = leafletMapRef.current;
              const proj = projectionRef.current;
              if (!map || !proj) return;
              const latLng = proj.locationToLatLng(coord.x, coord.y || 64, coord.z);
              map.setView(latLng, 5);
            }}
          />
        </Suspense>
      );
    }

    if (selectedPoint) {
      const { nearbyStations, nearbyLandmarks } = getNearbyPoints(selectedPoint.coord);
      return (
        <Suspense fallback={null}>
          <LazyPointDetailCard
            selectedPoint={selectedPoint}
            nearbyStations={nearbyStations}
            nearbyLandmarks={nearbyLandmarks}
            lines={lines}
            onClose={() => setSelectedPoint(null)}
            onStationClick={handleStationClick}
            onLandmarkClick={handleLandmarkClick}
            onLineClick={(line: ParsedLine) => {
              setSelectedPoint(null);
              handleLineSelect(line);
            }}
          />
        </Suspense>
      );
    }

    if (selectedPlayer) {
      return (
        <PlayerDetailCard
          player={selectedPlayer}
          worldId={currentWorld}
          onClose={() => setSelectedPlayer(null)}
          onNavigate={(player) => {
            setNavigationInitialEndPoint(buildNavigationInitialPointFromPlayer(player));
            setSelectedPlayer(null);
            setMobileActivePanel('navigation');
            setMobileSheetHidden(false);
            setMobileSheetCollapsed(false);
          }}
        />
      );
    }

    if (mobileActivePanel === 'featureJson') {
      return mobileFeatureJson ? (
        <MobileFeatureJsonPanel
          title={mobileFeatureJson.title}
          jsonText={mobileFeatureJson.jsonText}
          filename={mobileFeatureJson.filename}
        />
      ) : null;
    }

    if (mobileActivePanel === 'featureShare') {
      return mobileFeatureShare ? <MobileFeatureSharePanel payload={mobileFeatureShare} /> : null;
    }

    if (selectedRuleFeature) {
      const Card = resolveFeatureCardComponent(selectedRuleClassCode);
      return (
        <Card
          open
          feature={selectedRuleFeature}
          onClose={closeMobileSheet}
          resolveFeatureById={ruleResolveFeatureByIdRef.current}
          onTryTriggerLabelClickById={ruleTriggerLabelClickRef.current}
          variant="embedded"
          onOpenJsonPanel={(payload) => {
            suppressRuleFeatureCardOpenRef.current = true;
            setMobileFeatureJson(payload);
            setMobileFeatureShare(null);
            setMobileActivePanel('featureJson');
            setMobileSheetHidden(false);
            setMobileSheetCollapsed(false);
            setSelectedRuleFeature(null);
            setSelectedRuleClassCode(null);
            window.dispatchEvent(new CustomEvent('ria:ruleFeatureCardClose'));
          }}
          onOpenSharePanel={(payload) => {
            suppressRuleFeatureCardOpenRef.current = true;
            setMobileFeatureShare(payload);
            setMobileFeatureJson(null);
            setMobileActivePanel('featureShare');
            setMobileSheetHidden(false);
            setMobileSheetCollapsed(false);
            setSelectedRuleFeature(null);
            setSelectedRuleClassCode(null);
            window.dispatchEvent(new CustomEvent('ria:ruleFeatureCardClose'));
          }}
        />
      );
    }

    switch (mobileActivePanel) {
      case 'about':
        return <AboutCard onClose={closeMobileSheet} />;
      case 'settings':
        return <SettingsPanel onClose={closeMobileSheet} onOpenConfigStudio={() => { closeMobileSheet(); openConfigStudio(); }} onOpenConfigLab={configLab ? undefined : () => { closeMobileSheet(); openConfigLab(); }} reviewAuth={openriamapGithubReviewAuth} reviewAuthTitle="登录状态" reviewAuthLoginLabel="使用 GitHub 登录" />;
      case 'releaseRecords':
        return <PublicReleaseRecordsPanel showNativeClose showInlineRefresh onClose={closeMobileSheet} />;
      case 'navigation':
        return (
          <NavigationPanel
            configRuntime={configRuntime}
            stations={stations}
            lines={lines}
            landmarks={landmarks}
            players={PLAYER_FEATURE_ENABLED ? players : []}
            worldId={currentWorld}
            onRouteFound={handleRouteFound}
            onClose={closeMobileSheet}
            initialEndPoint={navigationInitialEndPoint}
            onPointClick={(coord) => {
              const map = leafletMapRef.current;
              const proj = projectionRef.current;
              if (!map || !proj) return;
              const latLng = proj.locationToLatLng(coord.x, coord.y || 64, coord.z);
              map.setView(latLng, 5);
            }}
          />
        );
      case 'attributeQuery':
        return (
          <AttributeQueryPanel
            worldId={currentWorld}
            onSelect={(r) => {
              handleSearchSelect(r);
            }}
            onClose={closeMobileSheet}
          />
        );
case 'players':
  if (!PLAYER_FEATURE_ENABLED) return null;
  return (
    <PlayersList
      worldId={currentWorld}
      onClose={closeMobileSheet}
      onPlayerSelect={(player) => {
        closeMobileSheet();
        handlePlayerClick(player);
      }}
      onNavigateToPlayer={(player) => {
        setNavigationInitialEndPoint(buildNavigationInitialPointFromPlayer(player));
        setMobileActivePanel('navigation');
        setMobileSheetHidden(false);
        setMobileSheetCollapsed(false);
      }}
    />
  );
      default:
        return null;
    }
  };

  return (
    <div
      className={`relative w-full h-full ${application.preferences.toolbar.compact?'cm-toolbar-compact':''}`}
      style={{ ['--ria-mobile-bottom-offset' as any]: `${mobileSheetOffset}px` }}
    >
      {/* 地图容器 */}
      <div ref={mapRef} className="w-full h-full" />

      {shareLookupState && (
        <div className="absolute top-4 left-1/2 z-[2400] w-[calc(100%-2rem)] max-w-sm -translate-x-1/2">
          <AppCard className="bg-white/95 border border-blue-100 shadow-xl">
            <div className="px-4 py-3 text-sm text-gray-800">
              <div className="font-semibold text-blue-700">{shareLookupState.pending.type === 'player' ? '正在打开玩家分享链接' : '正在打开分享链接'}</div>
              <div className="mt-1 text-xs text-gray-600">{getShareLookupText(shareLookupState)}</div>
              <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-gray-200">
                <div
                  className="h-full rounded-full bg-blue-500 transition-all duration-200"
                  style={{ width: `${getShareLookupProgress(shareLookupState)}%` }}
                />
              </div>
            </div>
          </AppCard>
        </div>
      )}

      {shareLinkMessage && (
        <div className="absolute top-4 left-1/2 z-[2500] w-[calc(100%-2rem)] max-w-sm -translate-x-1/2">
          <AppCard className="bg-white/95 border border-amber-200 shadow-xl">
            <div className="px-4 py-3 text-sm text-gray-800">
              <div className="font-semibold text-amber-700">分享链接无法打开</div>
              <div className="mt-1">{shareLinkMessage}</div>
              <div className="mt-3 flex justify-end">
                <AppButton
                  onClick={() => setShareLinkMessage(null)}
                  className="rounded-lg bg-amber-500 px-3 py-1.5 text-xs font-medium text-white hover:bg-amber-600"
                >
                  知道了
                </AppButton>
              </div>
            </div>
          </AppCard>
        </div>
      )}

      {moduleMode === 'review' && reviewModuleLoaded && (
        <Suspense fallback={null}>
          <LazyReviewModule
            activeWorldId={currentWorld}
            onClose={closeReviewModule}
            onLoadPackage={loadReviewPackageIntoWorkspace}
            activeWorkspaceSession={reviewSession}
            onCloseActiveWorkspace={closeBoundReviewWorkspace}
          />
        </Suspense>
      )}

      <ReviewConfirmationHost />

      {reviewAccessBlockedMessage ? (
        <div className="fixed inset-0 z-[14000] flex items-center justify-center bg-slate-950/55 p-4" role="dialog" aria-modal="true" aria-labelledby="review-access-gate-title">
          <AppCard className="w-full max-w-[460px] overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl">
            <div className="border-b border-slate-200 px-5 py-4"><h2 id="review-access-gate-title" className="text-lg font-bold text-slate-900">需要登录后才能进入审核</h2></div>
            <p className="whitespace-pre-wrap px-5 py-5 text-sm leading-6 text-slate-700">{reviewAccessBlockedMessage}</p>
            <div className="flex justify-end border-t border-slate-200 bg-slate-50 px-5 py-4">
              <AppButton
                className="rounded-xl bg-blue-600 px-4 py-2 text-sm text-white hover:bg-blue-700"
                onClick={() => {
                  setReviewAccessBlockedMessage(null);
                  if (window.matchMedia?.('(max-width: 639px)').matches) {
                    setMobileActivePanel('settings');
                    setMobileSheetHidden(false);
                    setMobileSheetCollapsed(false);
                  } else {
                    setShowSettings(true);
                  }
                  // The settings panel mounts after this click; defer the focus signal
                  // until its review-auth section has subscribed to it.
                  window.setTimeout(() => window.dispatchEvent(new CustomEvent('ria:focus-review-auth-settings')), 0);
                }}
              >
                确认并前往设置
              </AppButton>
            </div>
          </AppCard>
        </div>
      ) : null}

      {showPublicReleaseRecords && (
        <div className="hidden sm:block">
          <DraggablePanel
            id="public-release-records"
            defaultPosition={{ x: 760, y: 160 }}
            constrainExpandedToViewport
            expandedHeaderActions={<AppButton className="rounded-lg p-2 text-slate-500 hover:bg-slate-100" onClick={() => setPublicReleaseRecordsRefreshSignal((value) => value + 1)} title="刷新发布记录"><RefreshCw className="h-5 w-5" /></AppButton>}
          >
            <PublicReleaseRecordsPanel onClose={() => setShowPublicReleaseRecords(false)} refreshSignal={publicReleaseRecordsRefreshSignal} />
          </DraggablePanel>
        </div>
      )}

      {/* 规则驱动图层（总开关控制，worldId 切换自动重载） */}
      {mapReady && leafletMapRef.current && projectionRef.current && (
        <RuleDrivenLayer
          mapReady={mapReady}
          map={leafletMapRef.current}
          projection={projectionRef.current}
          worldId={currentWorld}
          visible={true}
          activeButtonIds={activeRuleButtonIds}
          configRuntime={configRuntime}
          bypassButtonFilter={nativeConfigLabActive}
        />
      )}


      {/* 铁路图层 - 有路径规划结果时隐藏 */}
      {!nativeConfigLabActive && legacyModuleLoaded && mapReady && leafletMapRef.current && projectionRef.current && (
        <Suspense fallback={null}>
          <LazyRailwayLayer
            map={leafletMapRef.current}
            projection={projectionRef.current}
            worldId={currentWorld}
            visible={showRailway && !showRouteOverlay}
            mapStyle={mapStyle}
            onStationClick={handleStationClick}
          />
        </Suspense>
      )}

      {/* 地标图层 - 有路径规划结果时隐藏 */}
      {!nativeConfigLabActive && legacyModuleLoaded && mapReady && leafletMapRef.current && projectionRef.current && (
        <Suspense fallback={null}>
          <LazyLandmarkLayer
            map={leafletMapRef.current}
            projection={projectionRef.current}
            worldId={currentWorld}
            visible={showLandmark && !showRouteOverlay}
            onLandmarkClick={handleLandmarkClick}
          />
        </Suspense>
      )}

{/* 玩家图层（临时关闭） */}
{PLAYER_FEATURE_ENABLED && mapReady && leafletMapRef.current && projectionRef.current && (
  <PlayerLayer
    map={leafletMapRef.current}
    projection={projectionRef.current}
    worldId={currentWorld}
    visible={showPlayers}
    players={players}
    onPlayerClick={handlePlayerClick}
  />
)}

      {/* 顶部区域：桌面端恢复原始布局；移动端仅保留搜索框与关于快捷按钮 */}
      <div className="hidden sm:flex absolute top-4 left-4 right-auto z-[1000] flex-col gap-2 sm:max-w-[300px]">
        <AppCard className="bg-white/90 px-3 py-2 sm:px-4">
          <h1 className="text-base sm:text-lg font-bold text-gray-800">RIA 在线地图</h1>
          <WorldSwitcher
            frameless
            worlds={WORLDS}
            currentWorld={currentWorld}
            onWorldChange={handleWorldChange}
          />
        </AppCard>

        <SearchBar
          disabled={!moduleEnabled('search')}
          configRuntime={configRuntime}
          variant="desktop"
          stations={searchStations}
          landmarks={searchLandmarks}
          lines={searchLines}
          players={PLAYER_FEATURE_ENABLED ? players : []}
          worldId={currentWorld}
          onSelect={handleSearchSelect}
          onLineSelect={handleLineSelect}
        />

        <Toolbar
          onNavigationClick={() => { setNavigationInitialEndPoint(null); void openNavigation(); }}
          onAttributeQueryClick={() => { setShowAttributeQuery(true); }}
          onLinesClick={handleOpenLegacyLinesPage}
          onPlayersClick={() => { setShowPlayersPage(true); }}
          onHelpClick={() => { setShowAbout(true); }}
          onSettingsClick={() => { setShowSettings(true); }}
        />

        {hasRoute && (
          <AppButton
            onClick={() => setRouteHighlight(null)}
            className="bg-gray-500 hover:bg-gray-600 text-white px-3 py-1.5 rounded-lg shadow-lg flex items-center gap-2 w-fit text-sm"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
            <span>清除路径</span>
          </AppButton>
        )}
      </div>

      <div className="sm:hidden absolute top-2 left-2 right-2 z-[1003]">
        <SearchBar
          disabled={!moduleEnabled('search')}
          configRuntime={configRuntime}
          variant="mobile"
          mobile
          stations={searchStations}
          landmarks={searchLandmarks}
          lines={searchLines}
          players={PLAYER_FEATURE_ENABLED ? players : []}
          worldId={currentWorld}
          onSelect={handleSearchSelect}
          onLineSelect={handleLineSelect}
          onAboutClick={() => openMobilePanel('about')}
        />
      </div>

      <div className="sm:hidden absolute right-2 top-[40%] -translate-y-1/2 z-[1001]">
        <MobileQuickDock
          activeKey={mobileQuickPanel}
          onToggle={(key) => toggleMobileQuickPanel(key as MobileQuickPanelKey)}
          items={[
            { key: 'worlds', label: '世界切换', icon: <Globe2 className="w-5 h-5" />, activeClassName: 'bg-rose-100 text-rose-700' },
            { key: 'toolbar', label: '工具栏', icon: <PanelsTopLeft className="w-5 h-5" />, activeClassName: 'bg-violet-100 text-violet-700' },
            { key: 'ruleButtons', label: '图层切换按钮', icon: <Layers3 className="w-5 h-5" />, activeClassName: 'bg-emerald-100 text-emerald-700' },
            { key: 'modeTools', label: '模式工具', icon: <SlidersHorizontal className="w-5 h-5" />, activeClassName: 'bg-sky-100 text-sky-700' },
          ]}
          directionMap={{ worlds: 'down', toolbar: 'down', ruleButtons: shouldShowMobileSheet ? 'up' : 'down', modeTools: shouldShowMobileSheet ? 'up' : 'down' }}
          renderPanel={(key) => {
            if (key === 'worlds') {
              return (
                <WorldSwitcher
                  frameless
                  mobile
                  worlds={WORLDS}
                  currentWorld={currentWorld}
                  onWorldChange={(worldId) => {
                    handleWorldChange(worldId);
                    setMobileQuickPanel(null);
                  }}
                />
              );
            }
            if (key === 'toolbar') {
              return (
                <Toolbar
                  frameless
                  mobile
                  onNavigationClick={() => moduleEnabled('navigation')&&openMobilePanel('navigation')}
                  onAttributeQueryClick={() => openMobilePanel('attributeQuery')}
                  onLinesClick={() => {
                    setMobileQuickPanel(null);
                    handleOpenLegacyLinesPage();
                  }}
                  onPlayersClick={() => openMobilePanel('players')}
                  onHelpClick={() => openMobilePanel('about')}
                  onSettingsClick={() => moduleEnabled('settings')&&openMobilePanel('settings')}
                />
              );
            }
            if (key === 'ruleButtons') {
              return (
                <RuleButtonPanel
                  frameless
                  mode="mobile"
                  activeButtonIds={activeRuleButtonIds}
                  onToggle={toggleRuleButton}
                  showPlayers={showPlayers}
                  onTogglePlayers={setShowPlayers}
                />
              );
            }
            return (
              <LayerControl
                frameless
                mobile
                dimBackground={dimBackground}
                mapStyle={mapStyle}
                onToggleDimBackground={setDimBackground}
                onToggleMapStyle={setMapStyle}
              >
                <ToolIconButton label="发布记录" icon={<History className="w-5 h-5" />} tone="purple" onClick={() => openMobilePanel('releaseRecords')} />
                <ToolIconButton label="测量工具" icon={<Ruler className="w-5 h-5" />} active={activeWorkspace === 'measurement'} disabled={!moduleEnabled('measurement')||workspaceTransitionPhase !== 'idle'} onClick={() => { requestMeasuringModuleEntry('mtools'); setMobileQuickPanel(null); }} />
                <ToolIconButton label="测绘" icon={<Pencil className="w-5 h-5" />} active={activeWorkspace === 'mapping'} disabled={!moduleEnabled('mapping')||workspaceTransitionPhase !== 'idle'} onClick={() => { requestMeasuringModuleEntry('measuring'); setMobileQuickPanel(null); }} />
              </LayerControl>
            );
          }}
          onDockHeightChange={setMobileQuickDockHeight}
          zoomControls={(
            <AppCard className="bg-white/92 p-1 flex flex-col gap-1 shadow-xl w-11 items-center">
              <AppButton
                onClick={() => leafletMapRef.current?.zoomIn()}
                className="h-9 w-9 text-gray-700 active:bg-gray-100"
                title="放大"
              >
                <Plus className="w-5 h-5" />
              </AppButton>
              <AppButton
                onClick={() => leafletMapRef.current?.zoomOut()}
                className="h-9 w-9 text-gray-700 active:bg-gray-100"
                title="缩小"
              >
                <Minus className="w-5 h-5" />
              </AppButton>
            </AppCard>
          )}
        />
      </div>

      <div
        className="sm:hidden absolute right-2 top-[40%] -translate-y-1/2 z-[1001] pointer-events-none"
        style={{ marginTop: `${mobileQuickDockHeight + 8}px` }}
      >
        <div className="pointer-events-auto">
          <MobileFloorPanel
            visible={Boolean(mobileFloorPanelState.visible && mobileFloorPanelState.floorOptions.length > 0)}
            collapsed={mobileFloorCollapsed}
            buildingName={mobileFloorPanelState.buildingName}
            floorOptions={mobileFloorPanelState.floorOptions}
            activeFloorIndex={mobileFloorPanelState.activeFloorIndex}
            onSelectFloor={handleMobileFloorSelect}
            onToggleCollapsed={() => setMobileFloorCollapsed((prev) => !prev)}
          />
        </div>
      </div>

      {/* 桌面端：可拖拽浮动面板 */}
      {/* 关于卡片 */}
      {showAbout && (
        <div className="hidden sm:block">
        <DraggablePanel
          id="about"
          defaultPosition={{ x: 16, y: 240 }}
        >
          <AboutCard onClose={() => setShowAbout(false)} />
        </DraggablePanel>
        </div>
      )}

      {/* 设置面板 */}
      {moduleEnabled('settings')&&showSettings && (
        <div className="hidden sm:block">
        <DraggablePanel
          id="settings"
          defaultPosition={{ x: 16, y: 240 }}
        >
          <SettingsPanel onClose={() => setShowSettings(false)} onOpenConfigStudio={() => { setShowSettings(false); openConfigStudio(); }} onOpenConfigLab={configLab ? undefined : () => { setShowSettings(false); openConfigLab(); }} reviewAuth={openriamapGithubReviewAuth} reviewAuthTitle="登录状态" reviewAuthLoginLabel="使用 GitHub 登录" />
        </DraggablePanel>
        </div>
      )}

      {/* 路径规划面板 */}
      {moduleEnabled('navigation')&&showNavigation && (
        <div className="hidden sm:block">
        <DraggablePanel
          id="navigation"
          defaultPosition={{ x: 16, y: 240 }}
        >
          <NavigationPanel
            configRuntime={configRuntime}
            stations={stations}
            lines={lines}
            landmarks={landmarks}
            players={PLAYER_FEATURE_ENABLED ? players : []}
            worldId={currentWorld}
            onRouteFound={handleRouteFound}
            onClose={() => { setShowNavigation(false); setNavigationInitialEndPoint(null); }}
            initialEndPoint={navigationInitialEndPoint}
            onPointClick={(coord) => {
              const map = leafletMapRef.current;
              const proj = projectionRef.current;
              if (!map || !proj) return;
              const latLng = proj.locationToLatLng(coord.x, coord.y || 64, coord.z);
              map.setView(latLng, 5);
            }}
          />
        </DraggablePanel>
        </div>
      )}

      {/* 按属性查询面板 */}
      {showAttributeQuery && (
        <div className="hidden sm:block">
        <DraggablePanel
          id="attributeQuery"
          defaultPosition={{ x: 16, y: 240 }}
        >
          <AttributeQueryPanel
            worldId={currentWorld}
            onSelect={(r) => {
              handleSearchSelect(r);
            }}
            onClose={() => setShowAttributeQuery(false)}
          />
        </DraggablePanel>
        </div>
      )}

      {/* 玩家列表面板 */}
      {PLAYER_FEATURE_ENABLED && showPlayersPage && (
        <div className="hidden sm:block">
        <DraggablePanel
          id="players"
          defaultPosition={{ x: 16, y: 240 }}
        >
          <PlayersList
            worldId={currentWorld}
            onClose={() => setShowPlayersPage(false)}
            onPlayerSelect={(player) => {
              handlePlayerClick(player);
            }}
            onNavigateToPlayer={(player) => {
              setNavigationInitialEndPoint(buildNavigationInitialPointFromPlayer(player));
              void openNavigation();
            }}
          />
        </DraggablePanel>
        </div>
      )}

      {/* 线路详情卡片 */}
      {legacyModuleLoaded && highlightedLine && (
        <div className="hidden sm:block">
        <DraggablePanel
          id="lineDetail"
          defaultPosition={{ x: 340, y: 16 }}
        >
          <Suspense fallback={null}>
          <LazyLineDetailCard
            line={highlightedLine}
            onClose={() => setHighlightedLine(null)}
            onStationClick={(_name: string, coord: Coordinate) => {
              const map = leafletMapRef.current;
              const proj = projectionRef.current;
              if (!map || !proj) return;
              const latLng = proj.locationToLatLng(coord.x, coord.y || 64, coord.z);
              map.setView(latLng, 5);
            }}
          />
          </Suspense>
        </DraggablePanel>
        </div>
      )}

      {/* 点位详情卡片 */}
      {legacyModuleLoaded && selectedPoint && (() => {
        const { nearbyStations, nearbyLandmarks } = getNearbyPoints(selectedPoint.coord);
        return (
          <div className="hidden sm:block">
          <DraggablePanel
            id="pointDetail"
            defaultPosition={{ x: 340, y: 16 }}
              >
            <Suspense fallback={null}>
            <LazyPointDetailCard
              selectedPoint={selectedPoint}
              nearbyStations={nearbyStations}
              nearbyLandmarks={nearbyLandmarks}
              lines={lines}
              onClose={() => setSelectedPoint(null)}
              onStationClick={handleStationClick}
              onLandmarkClick={handleLandmarkClick}
              onLineClick={(line) => {
                setSelectedPoint(null);
                handleLineSelect(line);
              }}
            />
            </Suspense>
          </DraggablePanel>
          </div>
        );
      })()}

      {/* 玩家详情卡片 */}
      {selectedPlayer && (
        <div className="hidden sm:block">
        <DraggablePanel
          id="playerDetail"
          defaultPosition={{ x: 340, y: 16 }}
          windowControlTone="light"
          expandedControlLayout="playerCardGrid"
          minimizedTitleNode={(
            <span className="flex min-w-0 items-center gap-2">
              <User className="h-4 w-4 flex-none text-cyan-600" />
              <span className="truncate">{selectedPlayer.name}</span>
            </span>
          )}
        >
          <PlayerDetailCard
            player={selectedPlayer}
            worldId={currentWorld}
            desktopWindowMode
            onClose={() => setSelectedPlayer(null)}
            onNavigate={(player) => {
              setNavigationInitialEndPoint(buildNavigationInitialPointFromPlayer(player));
              void openNavigation();
            }}
          />
        </DraggablePanel>
        </div>
      )}

      {/* 桌面端：右上角图层控制 */}
      <div className={`hidden sm:block absolute top-4 ${application.preferences.toolbar.position==='left'?'left-4':'right-4'} z-[1000]`}>
        <div className="flex items-start gap-2">
          {rulePanelCollapsed ? <ToolIconButton label="展开图层面板" icon={<Layers3 className="w-5 h-5" />} tone="green" onClick={() => setRulePanelCollapsed(false)} /> : <div className="flex items-start gap-1"><RuleButtonPanel
            activeButtonIds={activeRuleButtonIds}
            onToggle={toggleRuleButton}
            showPlayers={showPlayers}
            onTogglePlayers={setShowPlayers}
          /><ToolIconButton label="收起图层面板" icon={<PanelsTopLeft className="w-5 h-5" />} tone="gray" onClick={() => setRulePanelCollapsed(true)} /></div>}

          {modePanelCollapsed ? <ToolIconButton label="展开模式面板" icon={<SlidersHorizontal className="w-5 h-5" />} tone="blue" onClick={() => setModePanelCollapsed(false)} /> : <div className="flex items-start gap-1"><LayerControl
            dimBackground={dimBackground}
            mapStyle={mapStyle}
            onToggleDimBackground={setDimBackground}
            onToggleMapStyle={setMapStyle}
          >
          <div className="hidden sm:block"><ToolIconButton label="发布记录" icon={<History className="w-5 h-5" />} tone="purple" onClick={() => setShowPublicReleaseRecords(true)} /></div>
          <div className="hidden sm:block">
            <ToolIconButton
              label="测量工具"
              icon={<Ruler className="w-5 h-5" />}
              active={activeWorkspace === 'measurement'}
              tone="blue"
              disabled={!moduleEnabled('measurement')||workspaceTransitionPhase !== 'idle'}
              onClick={() => requestMeasuringModuleEntry('mtools')}
            />
          </div>
          <div ref={mappingLauncherAnchorRef} className="hidden sm:block">
            <ToolIconButton
              label="测绘"
              icon={<Pencil className="w-5 h-5" />}
              active={activeWorkspace === 'mapping'}
              tone="blue"
              disabled={!moduleEnabled('mapping')||workspaceTransitionPhase !== 'idle'}
              onClick={() => requestMeasuringModuleEntry('measuring')}
              className="h-11 w-11"
            />
          </div>
          <div className="hidden sm:block">
            <ReviewModuleLauncher
              active={activeWorkspace === 'review'}
              onClick={requestReviewModuleEntry}
              disabled={!moduleEnabled('review')||workspaceTransitionPhase !== 'idle'}
            />
          </div>

          </LayerControl><ToolIconButton label="收起模式面板" icon={<PanelsTopLeft className="w-5 h-5" />} tone="gray" onClick={() => setModePanelCollapsed(true)} /></div>}
        </div>
      </div>

      {/* Workspace bodies are independent of desktop toolbar visibility. */}
      {measuringModuleLoaded ? (
            <Suspense fallback={null}>
              {activeWorkspace === 'measurement' && moduleMode === 'mapping' ? <LazyMeasurementToolsModule
                ref={measurementToolsRef}
                mapReady={mapReady}
                leafletMapRef={leafletMapRef}
                projectionRef={projectionRef}
                closeSignal={measureToolsCloseSignal}
                openSignal={measurementToolsOpenSignal}
                onBecameActive={() => setMeasuringCloseSignal(v => v + 1)}
                onRequestOpen={() => requestMeasuringModuleEntry('mtools')}
                launcherSlot={() => null}
              /> : null}
              {activeWorkspace === 'review' && moduleMode === 'review' && reviewModuleLoaded && reviewSession ? <LazyReviewWorkspace
                key={`review-${workspaceInstanceKey}`}
                ref={measuringModuleRef}
                mapReady={mapReady}
                leafletMapRef={leafletMapRef}
                projectionRef={projectionRef}
                configRuntime={configRuntime}
                currentWorldId={currentWorld}
                closeSignal={measuringCloseSignal}
                openSignal={measuringOpenSignal}
                onBecameActive={() => setMeasureToolsCloseSignal((value) => value + 1)}
                launcherSlot={() => null}
                reviewSession={reviewSession}
                onReviewDirtyChange={setReviewWorkspaceDirty}
                onReviewSave={handleReviewSave}
                onReviewExitRequested={closeReviewWorkspace}
                onReviewPackageUpload={openriamapReviewPackageUploader.uploadPackage}
              /> : null}
              {activeWorkspace === 'mapping' && moduleMode === 'mapping' ? <LazyMappingWorkspace
                key={`mapping-${workspaceInstanceKey}`}
                ref={measuringModuleRef}
                mapReady={mapReady}
                leafletMapRef={leafletMapRef}
                projectionRef={projectionRef}
                configRuntime={configRuntime}
                currentWorldId={currentWorld}
                closeSignal={measuringCloseSignal}
                openSignal={measuringOpenSignal}
                onBecameActive={() => setMeasureToolsCloseSignal((value) => value + 1)}
                launcherSlot={() => null}
                onRequestOpen={() => requestMeasuringModuleEntry('measuring')}
                launcherAnchorRef={mappingLauncherAnchorRef}
                disablePackageUpload={configLab}
                onReviewPackageUpload={openriamapReviewPackageUploader.uploadPackage}
              /> : null}
            </Suspense>
      ) : null}

      <MobileBottomSheet
        open={shouldShowMobileSheet}
        hidden={mobileSheetHidden}
        collapsed={mobileSheetCollapsed}
        title={mobileSheetTitle}
        onClose={closeMobileSheet}
        onToggleCollapsed={() => {
          if (mobileSheetHidden) {
            setMobileSheetHidden(false);
            setMobileSheetCollapsed(false);
            return;
          }
          toggleMobileSheetCollapsed();
        }}
        onOffsetChange={setMobileSheetOffset}
      >
        {renderMobileSheetContent()}
      </MobileBottomSheet>

      {/* 路径高亮图层 */}
{mapReady && leafletMapRef.current && projectionRef.current && showRouteOverlay && routeHighlight && (
  <RouteHighlightLayer
    map={leafletMapRef.current}
    projection={projectionRef.current}
    route={routeHighlight}
  />
)}


      {/* 线路高亮图层 */}
      {mapReady && leafletMapRef.current && projectionRef.current && highlightedLine && showRailway && (
        <LineHighlightLayer
          map={leafletMapRef.current}
          projection={projectionRef.current}
          line={highlightedLine}
        />
      )}

      {/* 线路列表页面 */}
      {LINES_FEATURE_ENABLED && legacyModuleLoaded && showLinesPage && (
        <Suspense fallback={null}>
          <LazyLinesPage
            onBack={() => setShowLinesPage(false)}
            onLineSelect={(line) => {
              setShowLinesPage(false);
              handleLineSelect(line);
            }}
          />
        </Suspense>
      )}

      {/* 加载进度提示 */}
      <LoadingOverlay />
    </div>
  );
}

function ConfiguredMap(props:Parameters<typeof MapContainer>[0]){const generation=useSyncExternalStore(subscribeApplication,getApplicationGeneration,getApplicationGeneration);return <MapContainer key={generation} {...props}/>;}
export default ConfiguredMap;

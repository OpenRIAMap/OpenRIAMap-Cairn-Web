import { applicationWorldCodeMap, applicationWorldPrefixMap, subscribeApplication } from '@/core/project/applicationRuntime';
// File: src/components/Mapping/Workflow/BuildingWorkflow.tsx
import { useEffect, useMemo, useRef, useState } from 'react';
import type { WorkflowComponentProps, WorldPoint } from './WorkflowHost';
import * as wfRegistry from './workflowRegistryLabels';
import AppButton from '@/components/ui/AppButton';
import {
  EXT_VALUE_TYPE_TEXT,
  type ExtValueType,
  EXT_VALUE_TYPE_OPTIONS,
  listCatalogClassOptions,
} from '@/components/Common/featureFormats';
import WorkflowFeatureSearchSelect, { type SearchSelectConfig } from './WorkflowFeatureSearchSelect';

const WF_KEY = 'bud_building';

/**
 * BuildingWorkflow（工作流：建筑 / BUD）
 *
 * 结构对齐 NaturalLandWorkflow：
 * 1) 填写者信息（CreateBy）
 * 2) 信息填写（Class=BUD 下全部面要素：选择 Kind/SKind + 名称/简称/命名者/wiki + 额外可选字段 + extensions）
 * 3) BUD（建筑）绘制：完成后写入固定图层，并退出回到快捷测绘主页面
 */

type Step = 'creator' | 'info' | 'draw';

type InfoForm = {
  typeKey: string; // `${kind}|${skind}`
  name: string;
  catAbbr: string; // 仅用于组装 ID 的所属分类代号（不落盘）
  abbr: string;
  nomenclator: string;
  wiki?: string;

  brief?: string; // 简介
  // optional
  land?: string; // 所属大陆(一级)
  admLevel1?: string; // 所属聚落(一级) -> tags.Adm
  pop?: string; // 相关成员
};

type ExtensionItem = {
  extGroup: string;
  extKey: string;
  extType: ExtValueType;
  extValue: string;
};

let WORLD_ID_TO_CODE=applicationWorldCodeMap();

let WORLD_CODE_TO_PREFIX=applicationWorldPrefixMap();

function resolveWorldPrefix(worldIdRaw: string): string {
  const w = String(worldIdRaw ?? '').trim();
  if (!w) return 'Z';

  const asNum = Number(w);
  if (Number.isFinite(asNum) && WORLD_CODE_TO_PREFIX[asNum as any]) return WORLD_CODE_TO_PREFIX[asNum as any];

  const code = WORLD_ID_TO_CODE[w];
  if (Number.isFinite(code)) return WORLD_CODE_TO_PREFIX[code];

  if (/^[ZNHELY]$/i.test(w)) return w.toUpperCase();
  return 'Z';
}

function nonEmpty(s: string) {
  return String(s ?? '').trim().length > 0;
}

type TopNavProps = {
  title: string;
  showPrev?: boolean;
  showNext?: boolean;
  prevDisabled?: boolean;
  nextDisabled?: boolean;
  onPrev?: () => void;
  onNext?: () => void;
};

function TopNav(props: TopNavProps) {
  const { title, showPrev, showNext, prevDisabled, nextDisabled, onPrev, onNext } = props;
  return (
    <div className="flex items-center justify-between gap-2 mb-3">
      <div className="text-sm font-semibold">{title}</div>
      <div className="flex items-center gap-2">
        {showPrev ? (
          <AppButton
            className={`px-3 py-1.5 rounded text-sm border border-gray-300 bg-white text-gray-900 ${
              prevDisabled ? 'opacity-50 cursor-not-allowed' : 'hover:bg-gray-100'
            }`}
            disabled={!!prevDisabled}
            onClick={onPrev}
            type="button"
          >
            上一步
          </AppButton>
        ) : null}
        {showNext ? (
          <AppButton
            className={`px-3 py-1.5 rounded text-sm border border-gray-300 bg-white text-gray-900 ${
              nextDisabled ? 'opacity-50 cursor-not-allowed' : 'hover:bg-gray-100'
            }`}
            disabled={!!nextDisabled}
            onClick={onNext}
            type="button"
          >
            下一步
          </AppButton>
        ) : null}
      </div>
    </div>
  );
}

type LabeledInputProps = {
  label: string;
  value: string;
  placeholder?: string;
  onChange: (v: string) => void;
  type?: 'text' | 'number';
};

function LabeledInput(props: LabeledInputProps) {
  const { label, value, placeholder, onChange, type = 'text' } = props;
  return (
    <label className="block space-y-1">
      <div className="text-xs opacity-80">{label}</div>
      <input
        type={type}
        className="w-full border p-1 rounded text-sm"
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        onMouseDownCapture={(e) => e.stopPropagation()}
        onPointerDownCapture={(e) => e.stopPropagation()}
        onTouchStartCapture={(e) => e.stopPropagation()}
      />
    </label>
  );
}

function LabeledBriefInput(props: LabeledInputProps) {
  const { label, value, placeholder, onChange } = props;
  return (
    <label className="block space-y-1">
      <div className="text-xs opacity-80">{label}</div>
      <textarea
        className="w-full border p-2 rounded text-sm h-28 resize-none"
        value={value}
        placeholder={placeholder}
        rows={4}
        onChange={(e) => onChange(e.target.value.replace(/\r\n/g, '\n').replace(/\r/g, '\n'))}
        onMouseDownCapture={(e) => e.stopPropagation()}
        onPointerDownCapture={(e) => e.stopPropagation()}
        onTouchStartCapture={(e) => e.stopPropagation()}
      />
    </label>
  );
}

function normalizeAbbr(raw: string) {
  return String(raw ?? '')
    .trim()
    .replace(/\s+/g, '')
    .replace(/[^A-Za-z0-9_-]/g, '');
}

export default function BuildingWorkflow(props: WorkflowComponentProps) {
  const { bridge } = props;

  const bridgeRef = useRef(bridge);
  useEffect(() => {
    bridgeRef.current = bridge;
  }, [bridge]);

  const [step, setStep] = useState<Step>('creator');

  // Page 1
  const [creatorId, setCreatorId] = useState<string>(() => (bridgeRef.current.getEditorId?.() ?? '').trim());

  // Page 2
  const [info, setInfo] = useState<InfoForm>({
    typeKey: '',
    name: '',
    catAbbr: '',
    abbr: '',
    nomenclator: '',
    wiki: '',
    brief: '',
    land: '',
    admLevel1: '',
    pop: '',
  });
  const [extItems, setExtItems] = useState<ExtensionItem[]>([]);

  // Page 3
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string>('');

  const worldPrefix = useMemo(() => resolveWorldPrefix(bridge.getCurrentWorldId?.() ?? ''), [bridge]);

  // ===== 复用检索组件：所属地理单元 / 所属聚落 =====
  const landUnitSearchCfg: SearchSelectConfig = useMemo(
    () => ({
      cacheKey: 'ISG_NGF_LAD_WTB',
      filter: (fi: any) => {
        const cls = String(fi.Class ?? fi.class ?? '').trim();
        if (cls !== 'ISG') return false;
        const kind = String(fi.Kind ?? fi.Kind ?? fi?.tags?.Kind ?? fi?.tags?.Kind ?? '').trim();
        const skind = String(fi.SKind ?? fi.SKind ?? fi?.tags?.SKind ?? fi?.tags?.SKind ?? '').trim();
        return kind === 'NGF' && (skind === 'LAD' || skind === 'WTB');
      },
      getId: (fi: any) => String(fi.ID ?? fi.PgonID ?? fi.pgonID ?? '').trim(),
      getName: (fi: any) => String(fi.Name ?? fi.PgonName ?? fi.pgonName ?? '').trim(),
      formatOption: (name, id) => `${name}(${id})`,
    }),
    []
  );

  // NOTE: 旧版 UAdm / UAdmG 已合并为 tags.Adm（一级聚落文本）。
  const classCode = 'BUD';

  const typeOptions = useMemo(() => {
    return listCatalogClassOptions({ classCode, geom: '面' });
  }, []);

  const selected = useMemo(() => {
    const key = String(info.typeKey ?? '');
    if (!key) return null;
    const [kind, skind] = key.split('|');
    return typeOptions.find((o) => o.kind === kind && o.skind === skind) ?? null;
  }, [info.typeKey, typeOptions]);

  useEffect(() => {
    if (nonEmpty(creatorId)) {
      bridgeRef.current.setEditorId(creatorId.trim());
    }

    if (step !== 'draw') {
      bridgeRef.current.suspendDrawMode();
      setSaveError('');
      return;
    }

    bridgeRef.current.setDrawMode('polygon');
  }, [step, creatorId]);

  const canGoNextFromCreator = useMemo(() => nonEmpty(creatorId), [creatorId]);
  const abbrNormalized = useMemo(() => normalizeAbbr(info.abbr), [info.abbr]);

  const canGoNextFromInfo = useMemo(() => {
    return nonEmpty(info.typeKey) && nonEmpty(info.name) && nonEmpty(abbrNormalized);
  }, [info.typeKey, info.name, abbrNormalized]);

  const draftPolygon: WorldPoint[] = step === 'draw' ? (bridge.getTempPoints?.() ?? []) : [];

  const canCommit = useMemo(() => {
    return canGoNextFromInfo && Array.isArray(draftPolygon) && draftPolygon.length >= 3 && !saving;
  }, [canGoNextFromInfo, draftPolygon.length, saving]);

  const addExtensionRow = () => {
    setExtItems((prev) => [...prev, { extGroup: '', extKey: '', extType: EXT_VALUE_TYPE_TEXT, extValue: '' }]);
  };

  const updateExtensionRow = (idx: number, patch: Partial<ExtensionItem>) => {
    setExtItems((prev) => prev.map((it, i) => (i === idx ? { ...it, ...patch } : it)));
  };

  const removeExtensionRow = (idx: number) => {
    setExtItems((prev) => prev.filter((_, i) => i !== idx));
  };

  const commit = () => {
    if (!canCommit || !selected) return;
    setSaving(true);
    setSaveError('');

    try {
      const pts = bridgeRef.current.getTempPoints?.() ?? [];
      const coords = (Array.isArray(pts) ? pts : []) as any;

      const cat = normalizeAbbr(info.catAbbr ?? '');
      const buildingId = `${worldPrefix}${classCode}${cat ? `_${cat}` : ''}_${abbrNormalized}`;

      // extensions：先写入 link.wiki，再拼接用户自定义条目
      const extList: ExtensionItem[] = [];
      const wiki = String(info.wiki ?? '').trim();
      if (wiki) {
        extList.push({ extGroup: 'link', extKey: 'wiki', extType: EXT_VALUE_TYPE_TEXT, extValue: wiki });
      }

      const brief = String(info.brief ?? '').replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim();
      if (brief) {
        extList.push({ extGroup: 'character', extKey: 'brief', extType: EXT_VALUE_TYPE_TEXT, extValue: brief });
      }
      for (const it of extItems ?? []) {
        const g = String(it.extGroup ?? '').trim();
        const k = String(it.extKey ?? '').trim();
        if (!g || !k) continue;
        if (g === 'link' && k === 'wiki') continue;
        if (g === 'character' && k === 'brief') continue;
        extList.push({
          extGroup: g,
          extKey: k,
          extType: (it.extType ?? EXT_VALUE_TYPE_TEXT) as ExtValueType,
          extValue: String(it.extValue ?? ''),
        });
      }

      const tags: Array<{ tagKey: string; tagValue: any }> = [];
      const nom = String(info.nomenclator ?? '').trim();
      if (nom) tags.push({ tagKey: 'nomenclator', tagValue: nom });

      const land = String(info.land ?? '').trim();
      if (land) tags.push({ tagKey: 'Land', tagValue: land });

      const adm = String(info.admLevel1 ?? '').trim();
      if (adm) tags.push({ tagKey: 'Adm', tagValue: adm });

      const pop = String(info.pop ?? '').trim();
      if (pop) tags.push({ tagKey: 'Pop', tagValue: pop });

      const res = bridgeRef.current.commitFeature({
        subType: '建筑',
        mode: 'polygon',
        coords,
        editorId: creatorId.trim(),
        values: {
          ID: buildingId,
          Name: String(info.name ?? '').trim(),
          Kind: selected.kind,
          SKind: selected.skind,
        },
        groupInfo: {
          tags,
          extensions: extList.map((it) => ({
            extGroup: it.extGroup,
            extKey: it.extKey,
            extType: it.extType,
            extValue: it.extValue,
          })),
        },
      });

      if (!res.ok) {
        setSaveError(res.error || '保存失败');
        return;
      }

      bridgeRef.current.clearTempPoints();
      bridgeRef.current.exitWorkflowToSelector();
    } catch (e: any) {
      setSaveError(String(e?.message ?? e ?? '保存失败'));
    } finally {
      setSaving(false);
    }
  };

  // --------- render ----------
  if (step === 'creator') {
    return (
      <div className="p-3 rounded border border-gray-300 bg-white">
        <TopNav title="建筑：填写者信息" showNext nextDisabled={!canGoNextFromCreator} onNext={() => setStep('info')} />

        <div className="space-y-2">
          <LabeledInput label="填写者ID（CreateBy）" value={creatorId} placeholder="例如：YZ1825" onChange={(v) => setCreatorId(v)} />
          <div className="text-xs text-gray-600">该字段将写入 CreateBy（系统字段），用于标识本次测绘的编辑者。</div>
        </div>
      </div>
    );
  }

  if (step === 'info') {
    return (
      <div className="p-3 rounded border border-gray-300 bg-white">
        <TopNav
          title="建筑：信息填写"
          showPrev
          showNext
          prevDisabled={false}
          nextDisabled={!canGoNextFromInfo}
          onPrev={() => setStep('creator')}
          onNext={() => setStep('draw')}
        />

        <div className="space-y-3">
          <label className="block space-y-1">
            <div className="text-xs opacity-80">{wfRegistry.getWorkflowClassificationLabel(WF_KEY)}</div>
            <select
              className="w-full border p-1 rounded text-sm"
              value={info.typeKey}
              onChange={(e) => setInfo((prev) => ({ ...prev, typeKey: e.target.value }))}
              onMouseDownCapture={(e) => e.stopPropagation()}
              onPointerDownCapture={(e) => e.stopPropagation()}
              onTouchStartCapture={(e) => e.stopPropagation()}
            >
              <option value="">请选择...</option>
              {typeOptions.map((o) => (
                <option key={`${o.kind}|${o.skind}`} value={`${o.kind}|${o.skind}`}>
                  {o.label}
                </option>
              ))}
            </select>
          </label>

          <LabeledInput label={wfRegistry.getWorkflowFieldLabel(WF_KEY, 'Name')} value={info.name} placeholder="例如：主岛码头" onChange={(v) => setInfo((p) => ({ ...p, name: v }))} />
          <LabeledInput label={wfRegistry.getWorkflowAuxLabel(WF_KEY, 'catAbbr')} value={info.catAbbr} placeholder="例如：HH" onChange={(v) => setInfo((p) => ({ ...p, catAbbr: v }))} />
          <LabeledInput label={wfRegistry.getWorkflowAuxLabel(WF_KEY, 'abbr')} value={info.abbr} placeholder="例如：ZDMT" onChange={(v) => setInfo((p) => ({ ...p, abbr: v }))} />
          <LabeledInput label={wfRegistry.getWorkflowFieldLabel(WF_KEY, 'nomenclator')} value={info.nomenclator} placeholder="例如：Codusk" onChange={(v) => setInfo((p) => ({ ...p, nomenclator: v }))} />

          <div className="grid grid-cols-2 gap-2">
            <WorkflowFeatureSearchSelect
              bridge={bridge}
              label={wfRegistry.getWorkflowFieldLabel(WF_KEY, 'Land')}
              value={String(info.land ?? '')}
              placeholder="输入关键词检索：可匹配 Name / ID"
              config={landUnitSearchCfg}
              onChange={(v) => setInfo((p) => ({ ...p, land: v }))}
            />
            <LabeledInput
              label={wfRegistry.getWorkflowFieldLabel(WF_KEY, 'Adm')}
              value={String(info.admLevel1 ?? '')}
              placeholder="例如：鳕鱼鱼"
              onChange={(v) => setInfo((p) => ({ ...p, admLevel1: v }))}
            />
            <LabeledInput label={wfRegistry.getWorkflowFieldLabel(WF_KEY, 'Pop')} value={info.pop ?? ''} onChange={(v) => setInfo((p) => ({ ...p, pop: v }))} />
          </div>

          <LabeledInput label={wfRegistry.getWorkflowFieldLabel(WF_KEY, 'wiki')} value={info.wiki ?? ''} placeholder="例如：wiki.ria.red/xxx" onChange={(v) => setInfo((p) => ({ ...p, wiki: v }))} />



          <LabeledBriefInput
            label={wfRegistry.getWorkflowFieldLabel(WF_KEY, 'brief')}
            value={info.brief ?? ''}
            placeholder="支持长文本输入（不支持换行）"
            onChange={(v) => setInfo((prev) => ({ ...prev, brief: v }))}
          />
          <div className="pt-2 border-t">
            <div className="flex items-center justify-between">
              <div className="text-sm font-semibold">extensions（可选）</div>
              <AppButton type="button" className="px-2 py-1 text-xs border rounded hover:bg-gray-50" onClick={addExtensionRow}>
                + 添加
              </AppButton>
            </div>
            <div className="mt-2 space-y-2">
              {extItems.length === 0 ? <div className="text-xs text-gray-500">（无）</div> : null}
              {extItems.map((it, idx) => (
                <div key={idx} className="grid grid-cols-12 gap-2 items-center">
                  <input
                    className="col-span-3 border p-1 rounded text-xs"
                    placeholder="group"
                    value={it.extGroup}
                    onChange={(e) => updateExtensionRow(idx, { extGroup: e.target.value })}
                    onMouseDownCapture={(e) => e.stopPropagation()}
                    onPointerDownCapture={(e) => e.stopPropagation()}
                    onTouchStartCapture={(e) => e.stopPropagation()}
                  />
                  <input
                    className="col-span-3 border p-1 rounded text-xs"
                    placeholder="key"
                    value={it.extKey}
                    onChange={(e) => updateExtensionRow(idx, { extKey: e.target.value })}
                    onMouseDownCapture={(e) => e.stopPropagation()}
                    onPointerDownCapture={(e) => e.stopPropagation()}
                    onTouchStartCapture={(e) => e.stopPropagation()}
                  />
                  <select
                    className="col-span-3 border p-1 rounded text-xs"
                    value={it.extType}
                    onChange={(e) => updateExtensionRow(idx, { extType: e.target.value as ExtValueType })}
                    onMouseDownCapture={(e) => e.stopPropagation()}
                    onPointerDownCapture={(e) => e.stopPropagation()}
                    onTouchStartCapture={(e) => e.stopPropagation()}
                  >
                    {EXT_VALUE_TYPE_OPTIONS.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                  <input
                    className="col-span-2 border p-1 rounded text-xs"
                    placeholder="value"
                    value={it.extValue}
                    onChange={(e) => updateExtensionRow(idx, { extValue: e.target.value })}
                    onMouseDownCapture={(e) => e.stopPropagation()}
                    onPointerDownCapture={(e) => e.stopPropagation()}
                    onTouchStartCapture={(e) => e.stopPropagation()}
                  />
                  <AppButton
                    type="button"
                    className="col-span-1 px-2 py-1 text-xs border rounded hover:bg-gray-50"
                    onClick={() => removeExtensionRow(idx)}
                    title="删除"
                  >
                    ×
                  </AppButton>
                </div>
              ))}
            </div>

            <div className="mt-2 text-xs text-gray-600">提示：wiki 链接会自动写入 extensions.link.wiki；如需更多字段可在此添加。</div>
          </div>
        </div>
      </div>
    );
  }

  // draw
  return (
    <div className="p-3 rounded border border-gray-300 bg-white">
      <TopNav title="建筑：绘制（面）" showPrev prevDisabled={false} onPrev={() => setStep('info')} />

      <div className="text-xs text-gray-700 mb-2">
        请在地图上绘制面要素（至少 3 个点）。完成后点击“保存”。
      </div>

      <div className="text-xs text-gray-600 mb-2">
        当前点数：<span className="font-mono">{draftPolygon.length}</span>
      </div>

      {saveError ? <div className="text-xs text-red-600 mb-2">{saveError}</div> : null}

      <div className="flex items-center gap-2">
        <AppButton
          type="button"
          className={`px-3 py-1.5 rounded text-sm border ${canCommit ? 'hover:bg-gray-50' : 'opacity-50 cursor-not-allowed'}`}
          disabled={!canCommit}
          onClick={commit}
        >
          {saving ? '保存中...' : '保存'}
        </AppButton>
        <AppButton
          type="button"
          className="px-3 py-1.5 rounded text-sm border hover:bg-gray-50"
          onClick={() => {
            bridgeRef.current.clearTempPoints();
          }}
        >
          清空草稿
        </AppButton>
        <AppButton
          type="button"
          className="ml-auto px-3 py-1.5 rounded text-sm border hover:bg-gray-50"
          onClick={() => bridgeRef.current.exitWorkflowToSelector()}
        >
          返回
        </AppButton>
      </div>

      <div className="mt-3 text-xs text-gray-600">
        将写入：ID = {worldPrefix}BUD{info.catAbbr ? `_${normalizeAbbr(info.catAbbr)}` : ''}_{abbrNormalized}
      </div>
    </div>
  );
}

subscribeApplication(()=>{WORLD_ID_TO_CODE=applicationWorldCodeMap();WORLD_CODE_TO_PREFIX=applicationWorldPrefixMap();});

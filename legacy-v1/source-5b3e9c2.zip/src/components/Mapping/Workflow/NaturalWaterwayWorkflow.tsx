import { applicationWorldCodeMap, applicationWorldPrefixMap, subscribeApplication } from '@/core/project/applicationRuntime';
// File: src/components/Mapping/Workflow/NaturalWaterwayWorkflow.tsx
import { useEffect, useMemo, useRef, useState } from 'react';
import type { WorkflowComponentProps, WorldPoint } from './WorkflowHost';
import * as wfRegistry from './workflowRegistryLabels';
import AppButton from '@/components/ui/AppButton';
import {
  EXT_VALUE_TYPE_OPTIONS,
  EXT_VALUE_TYPE_TEXT,
  type ExtValueType,
  listCatalogSKind2Options,
} from '@/components/Common/featureFormats';

const WF_KEY = 'ngf_wtr';

/**
 * NaturalWaterwayWorkflow（工作流：自然要素-河道）
 *
 * 页面结构：
 * 1) 填写者信息（CreateBy）
 * 2) 信息填写（类型下拉 + 名称/简称/命名者/wiki + extensions）
 * 3) ISL（地物线）绘制：完成后写入固定图层，并退出回到快捷测绘主页面
 */

type Step = 'creator' | 'info' | 'draw';

type InfoForm = {
  skind2: string;
  name: string;
  abbr: string;
  nomenclator: string;
  wiki?: string;
  brief?: string; // 简介
};

type ExtensionItem = {
  extGroup: string;
  extKey: string;
  extType: ExtValueType;
  extValue: string;
};

let WORLD_ID_TO_CODE=applicationWorldCodeMap();

let WORLD_CODE_TO_PREFIX=applicationWorldPrefixMap();

function resolveWorldPrefix(worldIdRaw: string): string {
  const w = String(worldIdRaw ?? '').trim();
  if (!w) return 'Z';

  const asNum = Number(w);
  if (Number.isFinite(asNum) && WORLD_CODE_TO_PREFIX[asNum as any]) return WORLD_CODE_TO_PREFIX[asNum as any];

  const code = WORLD_ID_TO_CODE[w];
  if (Number.isFinite(code)) return WORLD_CODE_TO_PREFIX[code];

  if (/^[ZNHELY]$/i.test(w)) return w.toUpperCase();

  return 'Z';
}

function nonEmpty(s: string) {
  return String(s ?? '').trim().length > 0;
}

type TopNavProps = {
  title: string;
  showPrev?: boolean;
  showNext?: boolean;
  prevDisabled?: boolean;
  nextDisabled?: boolean;
  onPrev?: () => void;
  onNext?: () => void;
};

function TopNav(props: TopNavProps) {
  const { title, showPrev, showNext, prevDisabled, nextDisabled, onPrev, onNext } = props;
  return (
    <div className="flex items-center justify-between gap-2 mb-3">
      <div className="text-sm font-semibold">{title}</div>
      <div className="flex items-center gap-2">
        {showPrev ? (
          <AppButton
            className={`px-3 py-1.5 rounded text-sm border border-gray-300 bg-white text-gray-900 ${
              prevDisabled ? 'opacity-50 cursor-not-allowed' : 'hover:bg-gray-100'
            }`}
            disabled={!!prevDisabled}
            onClick={onPrev}
            type="button"
          >
            上一步
          </AppButton>
        ) : null}
        {showNext ? (
          <AppButton
            className={`px-3 py-1.5 rounded text-sm border border-gray-300 bg-white text-gray-900 ${
              nextDisabled ? 'opacity-50 cursor-not-allowed' : 'hover:bg-gray-100'
            }`}
            disabled={!!nextDisabled}
            onClick={onNext}
            type="button"
          >
            下一步
          </AppButton>
        ) : null}
      </div>
    </div>
  );
}

type LabeledInputProps = {
  label: string;
  value: string;
  placeholder?: string;
  onChange: (v: string) => void;
  type?: 'text' | 'number';
};

function LabeledInput(props: LabeledInputProps) {
  const { label, value, placeholder, onChange, type = 'text' } = props;
  return (
    <label className="block space-y-1">
      <div className="text-xs opacity-80">{label}</div>
      <input
        type={type}
        className="w-full border p-1 rounded text-sm"
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        onMouseDownCapture={(e) => e.stopPropagation()}
        onPointerDownCapture={(e) => e.stopPropagation()}
        onTouchStartCapture={(e) => e.stopPropagation()}
      />
    </label>
  );
}

function LabeledBriefInput(props: LabeledInputProps) {
  const { label, value, placeholder, onChange } = props;
  return (
    <label className="block space-y-1">
      <div className="text-xs opacity-80">{label}</div>
      <textarea
        className="w-full border p-2 rounded text-sm h-28 resize-none"
        value={value}
        placeholder={placeholder}
        rows={4}
        onChange={(e) => onChange(e.target.value.replace(/\r\n/g, '\n').replace(/\r/g, '\n'))}
        onMouseDownCapture={(e) => e.stopPropagation()}
        onPointerDownCapture={(e) => e.stopPropagation()}
        onTouchStartCapture={(e) => e.stopPropagation()}
      />
    </label>
  );
}

function normalizeAbbr(raw: string) {
  return String(raw ?? '')
    .trim()
    .replace(/\s+/g, '')
    .replace(/[^A-Za-z0-9_-]/g, '');
}

export default function NaturalWaterwayWorkflow(props: WorkflowComponentProps) {
  const { bridge } = props;

  const bridgeRef = useRef(bridge);
  useEffect(() => {
    bridgeRef.current = bridge;
  }, [bridge]);

  const [step, setStep] = useState<Step>('creator');

  // Page 1
  const [creatorId, setCreatorId] = useState<string>(() => (bridgeRef.current.getEditorId?.() ?? '').trim());

  // Page 2
  const [info, setInfo] = useState<InfoForm>({
    skind2: '',
    name: '',
    abbr: '',
    nomenclator: '',
    wiki: '',
  
    brief: '',});
  const [extItems, setExtItems] = useState<ExtensionItem[]>([]);

  // Page 3
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string>('');

  const worldPrefix = useMemo(() => resolveWorldPrefix(bridge.getCurrentWorldId?.() ?? ''), [bridge]);
  const kind = 'NGF';
  const skind = 'WTR';

  const skind2Options = useMemo(() => {
    return listCatalogSKind2Options({ kind, skind, geom: '线' });
  }, []);

  useEffect(() => {
    if (nonEmpty(creatorId)) {
      bridgeRef.current.setEditorId(creatorId.trim());
    }

    if (step !== 'draw') {
      bridgeRef.current.suspendDrawMode();
      setSaveError('');
      return;
    }

    bridgeRef.current.setDrawMode('polyline');
  }, [step, creatorId]);

  const canGoNextFromCreator = useMemo(() => nonEmpty(creatorId), [creatorId]);
  const abbrNormalized = useMemo(() => normalizeAbbr(info.abbr), [info.abbr]);

  const canGoNextFromInfo = useMemo(() => {
    return nonEmpty(info.skind2) && nonEmpty(info.name) && nonEmpty(abbrNormalized);
  }, [info.skind2, info.name, abbrNormalized]);

  const draftLine: WorldPoint[] = step === 'draw' ? (bridge.getTempPoints?.() ?? []) : [];

  const canCommit = useMemo(() => {
    return canGoNextFromInfo && Array.isArray(draftLine) && draftLine.length >= 2 && !saving;
  }, [canGoNextFromInfo, draftLine.length, saving]);

  const addExtensionRow = () => {
    setExtItems((prev) => [...prev, { extGroup: '', extKey: '', extType: EXT_VALUE_TYPE_TEXT, extValue: '' }]);
  };

  const updateExtensionRow = (idx: number, patch: Partial<ExtensionItem>) => {
    setExtItems((prev) => prev.map((it, i) => (i === idx ? { ...it, ...patch } : it)));
  };

  const removeExtensionRow = (idx: number) => {
    setExtItems((prev) => prev.filter((_, i) => i !== idx));
  };

  const commit = () => {
    if (!canCommit) return;
    setSaving(true);
    setSaveError('');

    try {
      const pts = bridgeRef.current.getTempPoints?.() ?? [];
      const coords = (Array.isArray(pts) ? pts : []) as any;

      const plineId = `${worldPrefix}${kind}${skind}${info.skind2}_${abbrNormalized}`;

      const extList: ExtensionItem[] = [];
      const wiki = String(info.wiki ?? '').trim();
      if (wiki) {
        extList.push({ extGroup: 'link', extKey: 'wiki', extType: EXT_VALUE_TYPE_TEXT, extValue: wiki });
      }

      const brief = String(info.brief ?? '').replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim();
      if (brief) {
        extList.push({ extGroup: 'character', extKey: 'brief', extType: EXT_VALUE_TYPE_TEXT, extValue: brief });
      }
      for (const it of extItems ?? []) {
        const g = String(it.extGroup ?? '').trim();
        const k = String(it.extKey ?? '').trim();
        if (!g || !k) continue;
        if (g === 'link' && k === 'wiki') continue;
        if (g === 'character' && k === 'brief') continue;
        extList.push({
          extGroup: g,
          extKey: k,
          extType: (it.extType ?? EXT_VALUE_TYPE_TEXT) as ExtValueType,
          extValue: String(it.extValue ?? ''),
        });
      }

      // tags：nomenclator 可选（若填写则写入 tags.nomenclator）
      const tags: Array<{ tagKey: string; tagValue: any }> = [];
      const nom = String(info.nomenclator ?? '').trim();
      if (nom) tags.push({ tagKey: 'nomenclator', tagValue: nom });

      const res = bridgeRef.current.commitFeature({
        subType: '地物线',
        mode: 'polyline',
        coords,
        editorId: creatorId.trim(),
        values: {
          ID: plineId,
          Name: String(info.name ?? '').trim(),
          Kind: kind,
          SKind: skind,
          SKind2: info.skind2,
        },
        groupInfo: {
          tags,
          extensions: extList.map((it) => ({
            extGroup: it.extGroup,
            extKey: it.extKey,
            extType: it.extType,
            extValue: it.extValue,
          })),
        },
      });

      if (!res.ok) {
        setSaveError(res.error || '保存失败');
        return;
      }

      bridgeRef.current.clearTempPoints();
      bridgeRef.current.exitWorkflowToSelector();
    } catch (e: any) {
      setSaveError(String(e?.message ?? e ?? '保存失败'));
    } finally {
      setSaving(false);
    }
  };

  if (step === 'creator') {
    return (
      <div className="p-3 rounded border border-gray-300 bg-white">
        <TopNav title="自然要素-河道：填写者信息" showNext nextDisabled={!canGoNextFromCreator} onNext={() => setStep('info')} />

        <div className="space-y-2">
          <LabeledInput label="填写者ID（CreateBy）" value={creatorId} placeholder="例如：YZ1825" onChange={(v) => setCreatorId(v)} />
          <div className="text-xs text-gray-600">该字段将写入 CreateBy（系统字段），用于标识本次测绘的编辑者。</div>
        </div>
      </div>
    );
  }

  if (step === 'info') {
    return (
      <div className="p-3 rounded border border-gray-300 bg-white">
        <TopNav
          title="自然要素-河道：信息填写"
          showPrev
          showNext
          prevDisabled={false}
          nextDisabled={!canGoNextFromInfo}
          onPrev={() => setStep('creator')}
          onNext={() => setStep('draw')}
        />

        <div className="space-y-3">
          <label className="block space-y-1">
            <div className="text-xs opacity-80">{wfRegistry.getWorkflowClassificationLabel(WF_KEY)}</div>
            <select
              className="w-full border p-1 rounded text-sm"
              value={info.skind2}
              onChange={(e) => setInfo((prev) => ({ ...prev, skind2: e.target.value }))}
              onMouseDownCapture={(e) => e.stopPropagation()}
              onPointerDownCapture={(e) => e.stopPropagation()}
              onTouchStartCapture={(e) => e.stopPropagation()}
            >
              <option value="">请选择...</option>
              {skind2Options.map((o) => (
                <option key={o.skind2} value={o.skind2}>
                  {o.label}
                </option>
              ))}
            </select>
          </label>

          <LabeledInput label={wfRegistry.getWorkflowFieldLabel(WF_KEY, 'Name')} value={info.name} placeholder="例如：北川" onChange={(v) => setInfo((prev) => ({ ...prev, name: v }))} />

          <LabeledInput
            label={wfRegistry.getWorkflowAuxLabel(WF_KEY, 'abbr')}
            value={info.abbr}
            placeholder="仅建议使用字母/数字/下划线/短横线"
            onChange={(v) => setInfo((prev) => ({ ...prev, abbr: v }))}
          />
          {info.abbr && abbrNormalized !== info.abbr.trim() ? (
            <div className="text-xs text-gray-600">
              将用于 ID 的简称：<span className="font-mono">{abbrNormalized || '(空)'}</span>
            </div>
          ) : null}

          <LabeledInput
            label={wfRegistry.getWorkflowFieldLabel(WF_KEY, 'nomenclator')}
            value={info.nomenclator}
            placeholder="例如：XX社团 / 聚落 / 个人署名"
            onChange={(v) => setInfo((prev) => ({ ...prev, nomenclator: v }))}
          />

          <LabeledInput
            label={wfRegistry.getWorkflowFieldLabel(WF_KEY, 'wiki')}
            value={info.wiki ?? ''}
            placeholder="https://..."
            onChange={(v) => setInfo((prev) => ({ ...prev, wiki: v }))}
          />



          <LabeledBriefInput
            label={wfRegistry.getWorkflowFieldLabel(WF_KEY, 'brief')}
            value={info.brief ?? ''}
            placeholder="支持长文本输入（不支持换行）"
            onChange={(v) => setInfo((prev) => ({ ...prev, brief: v }))}
          />
          <div className="border rounded p-2 bg-gray-50">
            <div className="flex items-center justify-between mb-2">
              <div className="text-sm font-semibold">extensions（可选）</div>
              <AppButton type="button" className="px-2 py-1 text-sm rounded border hover:bg-white" onClick={addExtensionRow}>
                添加扩展
              </AppButton>
            </div>

            {extItems.length === 0 ? (
              <div className="text-xs text-gray-600">暂无扩展项（你可以在此页添加任意扩展组/字段）。</div>
            ) : (
              <div className="space-y-2">
                {extItems.map((it, idx) => (
                  <div key={idx} className="grid grid-cols-12 gap-2 items-end">
                    <div className="col-span-3">
                      <LabeledInput label="组(extGroup)" value={it.extGroup} placeholder="例如：meta" onChange={(v) => updateExtensionRow(idx, { extGroup: v })} />
                    </div>
                    <div className="col-span-3">
                      <LabeledInput label="字段(extKey)" value={it.extKey} placeholder="例如：source" onChange={(v) => updateExtensionRow(idx, { extKey: v })} />
                    </div>
                    <div className="col-span-3">
                      <label className="block space-y-1">
                        <div className="text-xs opacity-80">值类型</div>
                        <select
                          className="w-full border p-1 rounded text-sm"
                          value={it.extType}
                          onChange={(e) => updateExtensionRow(idx, { extType: e.target.value as ExtValueType })}
                          onMouseDownCapture={(e) => e.stopPropagation()}
                          onPointerDownCapture={(e) => e.stopPropagation()}
                          onTouchStartCapture={(e) => e.stopPropagation()}
                        >
                          {EXT_VALUE_TYPE_OPTIONS.map((o) => (
                            <option key={o.value} value={o.value}>
                              {o.label}
                            </option>
                          ))}
                        </select>
                      </label>
                    </div>
                    <div className="col-span-2">
                      <LabeledInput
                        label="值(extValue)"
                        value={it.extValue}
                        placeholder={it.extType === 'null' ? 'null 类型可留空' : '...'}
                        onChange={(v) => updateExtensionRow(idx, { extValue: v })}
                      />
                    </div>
                    <div className="col-span-1">
                      <AppButton
                        type="button"
                        className="w-full px-2 py-1 text-sm rounded border bg-white hover:bg-gray-100"
                        onClick={() => removeExtensionRow(idx)}
                        title="删除"
                      >
                        ✕
                      </AppButton>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="text-xs text-gray-600">下一步将进入线要素绘制。完成后会写入 ISL（地物线）图层。</div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-3 rounded border border-gray-300 bg-white">
      <div className="flex items-center justify-between gap-2 mb-3">
        <div className="text-sm font-semibold">自然要素-河道：绘制（地物线 / ISL）</div>
        <div className="flex items-center gap-2">
          <AppButton
            type="button"
            className="px-3 py-1.5 rounded text-sm border border-gray-300 bg-white text-gray-900 hover:bg-gray-100"
            onClick={() => setStep('info')}
          >
            返回
          </AppButton>

          <AppButton
            type="button"
            className={`px-3 py-1.5 rounded text-sm border ${
              canCommit
                ? 'bg-emerald-600 text-white border-emerald-700 hover:bg-emerald-700'
                : 'bg-gray-200 text-gray-400 cursor-not-allowed border-gray-200'
            }`}
            disabled={!canCommit}
            onClick={commit}
            title={
              !canGoNextFromInfo
                ? '请先完善上一页信息'
                : (draftLine?.length ?? 0) < 2
                  ? '请先绘制至少 2 个点形成线'
                  : saving
                    ? '保存中'
                    : '完成并保存'
            }
          >
            {saving ? '保存中...' : '完成'}
          </AppButton>
        </div>
      </div>

      <div className="space-y-2">
        <div className="text-xs text-gray-600">绘制说明：当前已启用线绘制模式。请在地图上点击添加节点形成折线；完成后点击右上角“完成”。</div>

        <div className="text-xs text-gray-700">
          将生成：
          <div className="mt-1 font-mono text-xs break-all">
            ID = {worldPrefix}{kind}{skind}{info.skind2 || '...'}_{abbrNormalized || '...'}
          </div>
        </div>

        <div className="text-xs text-gray-700">
          当前点数：<span className="font-mono">{Array.isArray(draftLine) ? draftLine.length : 0}</span>
          <AppButton
            type="button"
            className="ml-2 px-2 py-1 text-sm rounded border bg-white hover:bg-gray-100"
            onClick={() => {
              bridgeRef.current.clearTempPoints();
            }}
          >
            清空草稿
          </AppButton>
        </div>

        {saveError ? <div className="text-sm text-red-600 whitespace-pre-wrap">{saveError}</div> : null}
      </div>
    </div>
  );
}

subscribeApplication(()=>{WORLD_ID_TO_CODE=applicationWorldCodeMap();WORLD_CODE_TO_PREFIX=applicationWorldPrefixMap();});

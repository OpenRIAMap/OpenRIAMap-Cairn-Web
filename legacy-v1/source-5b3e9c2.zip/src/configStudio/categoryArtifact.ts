import { dictionaryDependencies, dictionaryTableIds, remapDictionaryDependencies, type DictionaryFieldDependency } from './dictionaryDependencies';
import { linkCardInheritance } from './cardInheritance';
import { syncSystemClassification } from './systemClassification';
import { incomingNodeFieldSettings } from './nodeFieldSettings';
import JSZip from 'jszip';
import type { CategoryNode, ClassificationPath, ConfigPackageV3, ConfigValidationReport, FieldDefinition, LookupTable } from './types';
import { classificationPathKey, parentClassificationPath, pathDepth, resolveIncomingFields, resolveCardConfiguration, inheritanceControls, validateConfigPackage } from './runtime';
import { validateNativeStructure } from './nativeContractValidation';
import { createBlankV32Package } from './v32Defaults';
import { migrateConfigToR9 } from './r9Migration';
import { newConfigId } from './renderRuleTemplates';

export type CategoryArtifactPayload={schemaVersion:'cairnmap.category-artifact.v1'|'cairnmap.category-artifact.v2';contractRevision:9|10|11;fieldDependencies?:DictionaryFieldDependency[];lookupTables?:LookupTable[];kind:'node'|'classTree';projectId:string;classCode:string;path:ClassificationPath;nodes:CategoryNode[];ancestors:ClassificationPath[];engineFingerprint:string};
export type CategoryArtifact={payload:CategoryArtifactPayload;sha256:string};
export function categoryStableText(value:unknown):string {if(Array.isArray(value))return '['+value.map(categoryStableText).join(',')+']';if(value&&typeof value==='object')return '{'+Object.entries(value).filter(([,v])=>v!==undefined).sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>JSON.stringify(k)+':'+categoryStableText(v)).join(',')+'}';return JSON.stringify(value);}
async function digest(value:unknown):Promise<string>{return [...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(categoryStableText(value))))].map(b=>b.toString(16).padStart(2,'0')).join('');}
function inheritedFieldText(field:FieldDefinition,config:ConfigPackageV3):string{
  const {fieldId:_id,overrideOf:_override,...definition}=field;
  if(config.contractRevision>=10){const original=config.nodes.flatMap(node=>node.fields).find(row=>row.fieldId===field.fieldId);definition.inheritance=original?.inheritance??field.inheritance;if(field.optionsTableId||field.optionTable)delete definition.options;}
  return categoryStableText(definition);
}

function checkPayload(payload:CategoryArtifactPayload) {
  if(!payload||!([9,10,11].includes(payload.contractRevision))||payload.schemaVersion!==(payload.contractRevision>=10?'cairnmap.category-artifact.v2':'cairnmap.category-artifact.v1')||!['node','classTree'].includes(payload.kind)||!payload.classCode||!Array.isArray(payload.nodes)||!payload.nodes.length||payload.nodes.length>2048||!Array.isArray(payload.ancestors))throw Error('文件不是受支持的单分类/Class 树输出。');
  const shape=validateNativeStructure({...createBlankV32Package(),contractRevision:payload.contractRevision,lookupTables:payload.lookupTables,nodes:payload.nodes,workflows:[]});if(shape.length)throw Error(shape.map(i=>`${i.path}：${i.message}`).join('\n'));
  if(payload.nodes.some(node=>node.path.class!==payload.classCode)||payload.path?.class!==payload.classCode)throw Error('分类文件包含其他 Class 或范围身份不一致。');
  const ids=payload.nodes.map(node=>node.nodeId),paths=payload.nodes.map(node=>classificationPathKey(node.path));if(new Set(ids).size!==ids.length||new Set(paths).size!==paths.length)throw Error('分类文件内部节点 ID/路径重复。');
  for(const node of payload.nodes){const levels=['class','kind','skind','skind2'] as const;for(let index=1;index<levels.length;index++)if(node.path[levels[index]]&&!node.path[levels[index-1]])throw Error('分类路径层级不连续。');}
  if(payload.kind==='node'){if(payload.nodes.length!==1||classificationPathKey(payload.nodes[0].path)!==classificationPathKey(payload.path)||payload.nodes[0].children.length)throw Error('单分类文件必须只有一个节点且不带从属树。');}
  else {
    if(pathDepth(payload.path)!==1||!payload.nodes.some(node=>pathDepth(node.path)===1))throw Error('Class 树必须包含其 Class 根。');
    for(const node of payload.nodes){const parent=parentClassificationPath(node.path);if(parent&&!paths.includes(classificationPathKey(parent)))throw Error('Class 树中间祖先缺失。');for(const child of node.children)if(!ids.includes(child))throw Error('Class 树存在悬空子节点。');}
    for(const node of payload.nodes){const parent=parentClassificationPath(node.path);if(parent&&!payload.nodes.find(n=>classificationPathKey(n.path)===classificationPathKey(parent))!.children.includes(node.nodeId))throw Error('Class 树父子连接不完整。');}
  }
}
export async function createCategoryArtifact(config:ConfigPackageV3,nodeId:string,kind:'node'|'classTree'):Promise<CategoryArtifact> {
  const report=validateConfigPackage(config);if(!report.valid)throw Error('配置未通过核验，不能导出分类文件。');
  if(config.contractRevision!==9&&config.contractRevision!==10&&config.contractRevision!==11)throw Error('请先迁移并保存原生配置，再导出分类。');
  const selected=config.nodes.find(n=>n.nodeId===nodeId);if(!selected)throw Error('请选择要导出的分类。');
  const path=kind==='classTree'?{class:selected.path.class}:selected.path;
  const nodes=structuredClone(kind==='classTree'?config.nodes.filter(n=>n.path.class===path.class):[selected]);if(kind==='node')nodes[0].children=[];
  const ancestors:ClassificationPath[]=[];let parent=parentClassificationPath(path);while(parent){ancestors.unshift(parent);parent=parentClassificationPath(parent);}
  const tableIds=dictionaryTableIds(config,nodes);
  const lookupTables=config.lookupTables?.filter(table=>tableIds.has(table.id));
  const payload:CategoryArtifactPayload={schemaVersion:config.contractRevision>=10?'cairnmap.category-artifact.v2':'cairnmap.category-artifact.v1',contractRevision:config.contractRevision as 9|10|11,...(lookupTables?.length?{lookupTables:structuredClone(lookupTables)}:{}),...(config.contractRevision>=11?{fieldDependencies:dictionaryDependencies(config,nodes)}:{}),kind,projectId:config.projectId,classCode:path.class,path,nodes,ancestors,engineFingerprint:await digest(config.engine)};checkPayload(payload);return {payload,sha256:await digest(payload)};
}
export async function categoryArtifactBlob(artifact:CategoryArtifact,zip=true):Promise<Blob> {
  checkPayload(artifact.payload);if(artifact.sha256!==await digest(artifact.payload))throw Error('分类内容摘要无效。');
  if(!zip)return new Blob([JSON.stringify(artifact,null,2)],{type:'application/json'});
  const archive=new JSZip();archive.file('category.json',JSON.stringify(artifact.payload));archive.file('manifest.json',JSON.stringify({schemaVersion:'cairnmap.category-manifest.v1',sha256:artifact.sha256}));return archive.generateAsync({type:'blob',compression:'DEFLATE'});
}
export async function readCategoryArtifact(file:File):Promise<CategoryArtifact> {
  if(file.size>50*1024*1024)throw Error('分类文件超过 50 MiB。');
  let artifact:CategoryArtifact;
  if(file.name.toLowerCase().endsWith('.zip')) {const zip=await JSZip.loadAsync(await file.arrayBuffer()),body=zip.file('category.json'),manifest=zip.file('manifest.json');if(!body||!manifest)throw Error('ZIP 不是分类输出文件。');const header=JSON.parse(await manifest.async('string'));if(header.schemaVersion!=='cairnmap.category-manifest.v1')throw Error('分类 manifest 类型无效。');artifact={payload:JSON.parse(await body.async('string')),sha256:header.sha256};}
  else if(file.name.toLowerCase().endsWith('.json'))artifact=JSON.parse(await file.text());else throw Error('只接受分类 JSON/ZIP。');
  checkPayload(artifact.payload);if(artifact.sha256!==await digest(artifact.payload))throw Error('分类文件摘要不一致，拒绝导入。');return artifact;
}
export type CategoryImportResult={config:ConfigPackageV3;selectedId:string;classCode:string;kind:'node'|'classTree';conflicts:string[];changes:string[];report:ConfigValidationReport};

/** Candidate only: never mutates the saved package or merges old tree nodes. */
export function prepareCategoryImport(input:ConfigPackageV3,artifact:CategoryArtifact,fixConflicts=false):CategoryImportResult {
  checkPayload(artifact.payload);const config=input.contractRevision<9?migrateConfigToR9(input):structuredClone(input),payload=artifact.payload,changes:string[]=[],conflicts:string[]=[];
  if(payload.contractRevision>config.contractRevision)throw Error(`请先将总配置迁移到 r${payload.contractRevision} 或更高的受支持契约，再导入新版分类。`);
  if(payload.contractRevision<10&&config.contractRevision>=10)throw Error(`旧 r${payload.contractRevision} 分类文件未携带完整 contextBindings 与新版结构身份/搜索模块所需迁移上下文，不能可靠转换；直接覆盖还可能丢失当前主结构设置。请先在配置工作台导入原旧版完整配置包，升级后重新导出该单分类或 Class 树，再导入本包。原文件及当前配置未修改。`);
  for(const node of payload.nodes){const identities=new Map<string,string>();for(const field of node.fields){if(identities.has(field.fieldId))throw Error(`分类 ${classificationPathKey(node.path)} 的字段 ID ${field.fieldId} 重复，涉及 ${identities.get(field.fieldId)} / ${field.key}。存在歧义，不能猜测引用。请修复原文件后再导入。`);identities.set(field.fieldId,field.key);}if(node.card?.mode==='fields'&&new Set(node.card.items.map(item=>item.id)).size!==node.card.items.length)throw Error(`分类 ${classificationPathKey(node.path)} 的信息卡条目 ID 重复，请修复原文件后再导入。`);}
  for(const table of payload.lookupTables??[]){const existing=config.lookupTables?.find(row=>row.id===table.id);if(existing&&categoryStableText(existing)!==categoryStableText(table))throw Error(`对照表 ${table.id} 与主配置存在差异，不能覆盖其他引用。请先统一表格后导入。`);if(!existing)config.lookupTables=[...config.lookupTables??[],structuredClone(table)];}
  if(payload.kind==='node') {
    let parent=parentClassificationPath(payload.path);while(parent){if(!config.nodes.some(n=>classificationPathKey(n.path)===classificationPathKey(parent!)))throw Error(parent.kind?`不存在上级 ${classificationPathKey(parent)}，请选择导入整体分类树或逐级上传保存`:'不存在上级Class，请选择导入整体分类树或逐级上传保存');parent=parentClassificationPath(parent);}
  }
  const incoming=structuredClone(payload.nodes),old=config.nodes.filter(n=>payload.kind==='classTree'?n.path.class===payload.classCode:classificationPathKey(n.path)===classificationPathKey(payload.path));
  const retained=config.nodes.filter(n=>!old.some(item=>item.nodeId===n.nodeId)),used=new Set(retained.map(n=>n.nodeId)),idMap=new Map<string,string>();
  for(const node of incoming){const previous=old.find(n=>classificationPathKey(n.path)===classificationPathKey(node.path));let id=previous?.nodeId??node.nodeId;if(used.has(id)){conflicts.push(`节点 ID 冲突：${id}`);id=newConfigId('node');}used.add(id);idMap.set(node.nodeId,id);node.nodeId=id;}
  for(const node of incoming){node.children=node.children.map(id=>idMap.get(id)??id);if(node.card?.mode==='fields')for(const item of node.card.items)if(item.inheritFrom)item.inheritFrom.nodeId=idMap.get(item.inheritFrom.nodeId)??item.inheritFrom.nodeId;}
  if(payload.kind==='node')incoming[0].children=old[0]?.children??[];
  if(config.contractRevision>=10&&payload.kind==='node'&&incoming[0].card?.mode==='fields'&&old[0]?.card?.mode==='fields'){
    const previous=old[0].card.items,used=new Set<string>();
    for(const item of incoming[0].card.items){const exact=previous.find(row=>row.id===item.id),matches=previous.filter(row=>row.source===item.source&&row.renderer===item.renderer&&row.section===item.section&&!used.has(row.id)),match=exact??(matches.length===1?matches[0]:undefined);if(match&&!used.has(match.id)){item.id=match.id;used.add(match.id);}}
  }
  const fieldIds=new Set(retained.flatMap(n=>n.fields.map(f=>f.fieldId)));
  for(const node of incoming){const parent=parentClassificationPath(node.path),upstream=parent?resolveIncomingFields({...config,nodes:[...retained,...incoming]},node.path):[];
    for(const field of node.fields){const fixed=upstream.find(f=>f.key===(field.overrideOf??field.key));if(fixed){if(inheritedFieldText(field,config)!==inheritedFieldText(fixed,config))conflicts.push(`固定继承字段冲突：${classificationPathKey(node.path)} / ${field.key}`);}}
    node.fields=node.fields.filter(field=>{const fixed=upstream.find(f=>f.key===(field.overrideOf??field.key));if(!fixed)return true;return !fixConflicts&&inheritedFieldText(field,config)!==inheritedFieldText(fixed,config);});
    if(config.contractRevision>=10){const inherited=incomingNodeFieldSettings({...config,nodes:[...retained,...incoming]},node);for(const module of ['structure','search'] as const){const fixed=inherited[module],local=node.fieldSettings?.[module];if(fixed&&local&&(module==='structure'||inherited.search?.inheritance==='sealed')){if(categoryStableText(fixed)!==categoryStableText(local))conflicts.push(`固定继承模块冲突：${classificationPathKey(node.path)} / ${module}`);if(fixConflicts||categoryStableText(fixed)===categoryStableText(local))delete node.fieldSettings![module];}}}
    const previous=old.find(n=>classificationPathKey(n.path)===classificationPathKey(node.path));
    for(const field of node.fields){const same=previous?.fields.find(f=>f.key===field.key);if(same)field.fieldId=same.fieldId;else if(fieldIds.has(field.fieldId)){conflicts.push(`字段 ID 冲突：${field.fieldId}`);field.fieldId=newConfigId('field');}fieldIds.add(field.fieldId);}
  }
  for(const node of retained)node.children=node.children.map(id=>old.find(n=>n.nodeId===id)?incoming.find(n=>classificationPathKey(n.path)===classificationPathKey(old.find(n=>n.nodeId===id)!.path))?.nodeId??id:id);
  config.nodes=[...retained,...incoming];
  if(payload.contractRevision>=11)remapDictionaryDependencies(config,incoming,structuredClone(payload.fieldDependencies??[]));
  if(config.contractRevision>=10&&payload.kind==='node'){const node=incoming[0],parent=parentClassificationPath(node.path),owner=parent?config.nodes.find(row=>classificationPathKey(row.path)===classificationPathKey(parent)):undefined;if(owner&&inheritanceControls(owner).card)linkCardInheritance(node,resolveCardConfiguration(config,owner.path),owner.nodeId);}
  if(payload.kind==='node'){const parent=parentClassificationPath(payload.path),owner=parent?config.nodes.find(n=>classificationPathKey(n.path)===classificationPathKey(parent)):undefined;if(owner&&!owner.children.includes(incoming[0].nodeId))owner.children.push(incoming[0].nodeId);}
  config.workflows=syncSystemClassification(config).workflows;
  const newPaths=new Set(incoming.map(n=>classificationPathKey(n.path)));for(const node of old)if(!newPaths.has(classificationPathKey(node.path)))changes.push(`删除 ${classificationPathKey(node.path)}`);for(const node of incoming)changes.push(`${old.some(n=>classificationPathKey(n.path)===classificationPathKey(node.path))?'替换':'新增'} ${classificationPathKey(node.path)}`);
  return {config,selectedId:incoming.find(n=>classificationPathKey(n.path)===classificationPathKey(payload.path))!.nodeId,classCode:payload.classCode,kind:payload.kind,conflicts,changes,report:validateConfigPackage(config)};
}

/** Replace exactly this Class, using current global/other-Class content. */
export function prepareClassTreeCommit(current:ConfigPackageV3,baseline:ConfigPackageV3,staged:ConfigPackageV3,classCode:string):ConfigPackageV3 {
  if(current.contractRevision<9)current=migrateConfigToR9(current);
  if(baseline.contractRevision<9)baseline=migrateConfigToR9(baseline);
  const tree=(config:ConfigPackageV3)=>config.nodes.filter(node=>node.path.class===classCode);
  if(categoryStableText(tree(current))!==categoryStableText(tree(baseline)))throw Error('主配置中的同 Class 树已发生变化，请重新导入/核验，未覆盖较新的修改。');
  const outside=(config:ConfigPackageV3)=>({...config,lookupTables:undefined,nodes:config.nodes.filter(node=>node.path.class!==classCode),workflows:config.workflows.map(workflow=>({...workflow,steps:workflow.steps.map(step=>({...step,controls:step.controls?.filter(control=>!(control.kind==='classificationPicker'&&control.systemManaged))}))}))});
  const needed=dictionaryTableIds(staged,tree(staged));
  const tables=[...current.lookupTables??[]];
  for(const table of staged.lookupTables??[]){const original=baseline.lookupTables?.find(row=>row.id===table.id);if(original){if(categoryStableText(original)!==categoryStableText(table))throw Error('Class 树模式不能修改共享对照表。');continue;}if(!needed.has(table.id))throw Error('Class 树包含范围外的新对照表。');const existing=tables.find(row=>row.id===table.id);if(existing&&categoryStableText(existing)!==categoryStableText(table))throw Error(`对照表 ${table.id} 已由其他保存修改，请重新导入。`);if(!existing)tables.push(structuredClone(table));}
  if(baseline.lookupTables?.some(table=>!staged.lookupTables?.some(row=>row.id===table.id)))throw Error('Class 树模式不能删除共享对照表。');
  if(categoryStableText(outside(staged))!==categoryStableText(outside(baseline)))throw Error('暂存 Class 树修改了范围外内容，不能注入。');
  const nodes=tree(staged);if(!nodes.some(node=>pathDepth(node.path)===1))throw Error('暂存树缺少 Class 根。');
  const candidate={...current,...(tables.length?{lookupTables:tables}:{}),nodes:[...current.nodes.filter(node=>node.path.class!==classCode),...structuredClone(nodes)]};
  candidate.workflows=syncSystemClassification(candidate).workflows;
  const report=validateConfigPackage(candidate);if(!report.valid)throw Error(report.issues.filter(issue=>issue.severity==='error').map(issue=>`${issue.path}：${issue.message}`).join('\n'));return candidate;
}

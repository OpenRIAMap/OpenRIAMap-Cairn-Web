import{r as c,M as g,bb as y,bc as $,bd as x,be as M}from"./main-B3MI08oP.js";import"./index-zyKrbkfF.js";function v({icon:a,color:o,size:e=24}){const s={landmark:'<path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',station:'<path d="M8 3.89l4-1.9 4 1.9"/><rect width="14" height="8" x="5" y="8" rx="1"/><circle cx="9" cy="21" r="1"/><circle cx="15" cy="21" r="1"/><path d="M9 16v5"/><path d="M15 16v5"/>',walk:'<path d="M4 16v-2.38C4 11.5 2.97 10.5 3 8c.03-2.72 1.49-6 4.5-6C9.37 2 10 3.8 10 5.5c0 3.11-2 5.66-2 8.68V16a2 2 0 1 1-4 0Z"/><path d="M20 20v-2.38c0-2.12 1.03-3.12 1-5.62-.03-2.72-1.49-6-4.5-6C14.63 6 14 7.8 14 9.5c0 3.11 2 5.66 2 8.68V20a2 2 0 1 0 4 0Z"/><path d="M16 17h4"/><path d="M4 13h4"/>',player:'<circle cx="12" cy="8" r="5"/><path d="M20 21a8 8 0 0 0-16 0"/>'}[a],n=e*.5,i=(e-n)/2;return`
    <svg width="${e}" height="${e}" viewBox="0 0 ${e} ${e}" xmlns="http://www.w3.org/2000/svg">
      <circle cx="${e/2}" cy="${e/2}" r="${e/2-1}" fill="${o}" stroke="white" stroke-width="2"/>
      <g transform="translate(${i}, ${i}) scale(${n/24})" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        ${s}
      </g>
    </svg>
  `}function w(a,o,e=24){return v({icon:a,color:o,size:e})}function E({map:a,projection:o,worldId:e,visible:u=!0,onLandmarkClick:s}){const[n,i]=c.useState([]),d=c.useRef(null);return c.useEffect(()=>{let t=!1;async function r(){i([]);const h=await x(e),f=M(h);t||i(f)}return r(),()=>{t=!0}},[e]),c.useEffect(()=>{if(!a)return;const t=g.layerGroup();return d.current=t,u&&t.addTo(a),()=>{t.remove(),d.current===t&&(d.current=null)}},[a]),c.useEffect(()=>{const t=d.current;if(t&&(t.clearLayers(),n.length!==0))for(const r of n){if(!r.coord||!Number.isFinite(r.coord.x)||!Number.isFinite(r.coord.y)||!Number.isFinite(r.coord.z))continue;const h=o.locationToLatLng(r.coord.x,r.coord.y,r.coord.z),f=y(r.grade),l=$(r.grade)*4,m=g.divIcon({className:"landmark-marker-icon",html:w("landmark",f,l),iconSize:[l,l],iconAnchor:[l/2,l/2]}),p=g.marker(h,{icon:m});p.bindTooltip(`<b>#${r.id} ${r.name}</b><br/>${r.grade}`,{permanent:!1,direction:"top",offset:[0,-5]}),s&&p.on("click",()=>{s(r)});const k=`
        <div class="landmark-popup">
          <h3 style="margin: 0 0 8px 0; font-size: 14px;">#${r.id} ${r.name}</h3>
          <p style="margin: 0; font-size: 12px;">
            等级: <span style="color: ${f}; font-weight: bold;">${r.grade}</span>
          </p>
          <p style="margin: 4px 0 0 0; font-size: 12px; color: #666;">
            坐标: X ${Math.round(r.coord.x)}, Z ${Math.round(r.coord.z)}
          </p>
        </div>
      `;p.bindPopup(k),t.addLayer(p)}},[n,o,s]),c.useEffect(()=>{const t=d.current;!t||!a||(u?a.hasLayer(t)||t.addTo(a):a.hasLayer(t)&&a.removeLayer(t))},[u,a]),null}export{E as LandmarkLayer,E as default};

import{c as o}from"./main-B3MI08oP.js";import"./index-zyKrbkfF.js";/**
 * @license lucide-react v0.561.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=[["path",{d:"m8 3 4 8 5-5 5 15H2L8 3z",key:"otkl63"}]],c=o("mountain",t);export{t as __iconNode,c as default};
